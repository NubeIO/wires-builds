### Commands available

- `bash script.bash -h`
- `sudo bash script.bash start -service_name=nubeio-rubix-wires.service -u=pi -dir=/home/pi/wires-builds/rubix-wires -data_dir=/data/wires -p=1313`
- `bash script.bash disable`
- `bash script.bash enable`
- `bash script.bash delete`
