var influxdbApis = (function (exports) {
    'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    /**
     * Base class for all apis.
     */
    var APIBase = /** @class */ (function () {
        /**
         * Initializes transport to communicate with InfluxDB.
         * @param influxDB - the main InfluxDB client object
         */
        function APIBase(influxDB) {
            if (!influxDB)
                throw new Error('No influxDB supplied!');
            if (!influxDB.transport)
                throw new Error('No transport supplied!');
            this.transport = influxDB.transport;
        }
        APIBase.prototype.queryString = function (request, params) {
            if (request && params) {
                return params.reduce(function (acc, key) {
                    var val = request[key];
                    if (val !== undefined && val !== null) {
                        acc += acc ? '&' : '?';
                        acc += encodeURIComponent(key) + '=' + encodeURIComponent(String(val));
                    }
                    return acc;
                }, '');
            }
            else {
                return '';
            }
        };
        APIBase.prototype.request = function (method, path, request, requestOptions, mediaType) {
            if (request === void 0) { request = {}; }
            var sendOptions = __assign(__assign({}, requestOptions), { method: method });
            if (mediaType) {
                (sendOptions.headers || (sendOptions.headers = {}))['content-type'] = mediaType;
            }
            if (request.auth) {
                var value = request.auth.user + ":" + request.auth.password;
                (sendOptions.headers || (sendOptions.headers = {}))['authorization'] =  btoa(value)
                    ;
            }
            return this.transport.request(path, request.body ? request.body : '', sendOptions);
        };
        return APIBase;
    }());

    /**
     * Root API
     */
    var RootAPI = /** @class */ (function () {
        /**
         * Creates RootAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function RootAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Map of all top level routes available.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetRoutes }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        RootAPI.prototype.getRoutes = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/", request, requestOptions);
        };
        return RootAPI;
    }());

    /**
     * Authorizations API
     */
    var AuthorizationsAPI = /** @class */ (function () {
        /**
         * Creates AuthorizationsAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function AuthorizationsAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all authorizations.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetAuthorizations }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        AuthorizationsAPI.prototype.getAuthorizations = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/authorizations" + this.base.queryString(request, [
                'userID',
                'user',
                'orgID',
                'org',
            ]), request, requestOptions);
        };
        /**
         * Create an authorization.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostAuthorizations }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        AuthorizationsAPI.prototype.postAuthorizations = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/authorizations", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve an authorization.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetAuthorizationsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        AuthorizationsAPI.prototype.getAuthorizationsID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/authorizations/" + request.authID, request, requestOptions);
        };
        /**
         * Update an authorization to be active or inactive.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PatchAuthorizationsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        AuthorizationsAPI.prototype.patchAuthorizationsID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/authorizations/" + request.authID, request, requestOptions, 'application/json');
        };
        /**
         * Delete a authorization.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteAuthorizationsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        AuthorizationsAPI.prototype.deleteAuthorizationsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/authorizations/" + request.authID, request, requestOptions);
        };
        return AuthorizationsAPI;
    }());

    /**
     * Buckets API
     */
    var BucketsAPI = /** @class */ (function () {
        /**
         * Creates BucketsAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function BucketsAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all buckets.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetBuckets }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.getBuckets = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/buckets" + this.base.queryString(request, [
                'offset',
                'limit',
                'after',
                'org',
                'orgID',
                'name',
            ]), request, requestOptions);
        };
        /**
         * Create a bucket.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostBuckets }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.postBuckets = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/buckets", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a bucket.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetBucketsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.getBucketsID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/buckets/" + request.bucketID, request, requestOptions);
        };
        /**
         * Update a bucket.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PatchBucketsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.patchBucketsID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/buckets/" + request.bucketID, request, requestOptions, 'application/json');
        };
        /**
         * Delete a bucket.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteBucketsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.deleteBucketsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/buckets/" + request.bucketID, request, requestOptions);
        };
        /**
         * List all labels for a bucket.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetBucketsIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.getBucketsIDLabels = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/buckets/" + request.bucketID + "/labels", request, requestOptions);
        };
        /**
         * Add a label to a bucket.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostBucketsIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.postBucketsIDLabels = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/buckets/" + request.bucketID + "/labels", request, requestOptions, 'application/json');
        };
        /**
         * delete a label from a bucket.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteBucketsIDLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.deleteBucketsIDLabelsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/buckets/" + request.bucketID + "/labels/" + request.labelID, request, requestOptions);
        };
        /**
         * List all users with member privileges for a bucket.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetBucketsIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.getBucketsIDMembers = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/buckets/" + request.bucketID + "/members", request, requestOptions);
        };
        /**
         * Add a member to a bucket.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostBucketsIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.postBucketsIDMembers = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/buckets/" + request.bucketID + "/members", request, requestOptions, 'application/json');
        };
        /**
         * Remove a member from a bucket.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteBucketsIDMembersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.deleteBucketsIDMembersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/buckets/" + request.bucketID + "/members/" + request.userID, request, requestOptions);
        };
        /**
         * List all owners of a bucket.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetBucketsIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.getBucketsIDOwners = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/buckets/" + request.bucketID + "/owners", request, requestOptions);
        };
        /**
         * Add an owner to a bucket.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostBucketsIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.postBucketsIDOwners = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/buckets/" + request.bucketID + "/owners", request, requestOptions, 'application/json');
        };
        /**
         * Remove an owner from a bucket.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteBucketsIDOwnersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        BucketsAPI.prototype.deleteBucketsIDOwnersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/buckets/" + request.bucketID + "/owners/" + request.userID, request, requestOptions);
        };
        return BucketsAPI;
    }());

    /**
     * Checks API
     */
    var ChecksAPI = /** @class */ (function () {
        /**
         * Creates ChecksAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function ChecksAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Get all checks.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetChecks }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ChecksAPI.prototype.getChecks = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/checks" + this.base.queryString(request, [
                'offset',
                'limit',
                'orgID',
            ]), request, requestOptions);
        };
        /**
         * Add new check.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/CreateCheck }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ChecksAPI.prototype.createCheck = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/checks", request, requestOptions, 'application/json');
        };
        /**
         * Get a check.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetChecksID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ChecksAPI.prototype.getChecksID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/checks/" + request.checkID, request, requestOptions);
        };
        /**
         * Update a check.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PutChecksID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ChecksAPI.prototype.putChecksID = function (request, requestOptions) {
            return this.base.request('PUT', "/api/v2/checks/" + request.checkID, request, requestOptions, 'application/json');
        };
        /**
         * Update a check.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PatchChecksID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ChecksAPI.prototype.patchChecksID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/checks/" + request.checkID, request, requestOptions, 'application/json');
        };
        /**
         * Delete a check.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteChecksID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ChecksAPI.prototype.deleteChecksID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/checks/" + request.checkID, request, requestOptions);
        };
        /**
         * List all labels for a check.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetChecksIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ChecksAPI.prototype.getChecksIDLabels = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/checks/" + request.checkID + "/labels", request, requestOptions);
        };
        /**
         * Add a label to a check.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostChecksIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ChecksAPI.prototype.postChecksIDLabels = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/checks/" + request.checkID + "/labels", request, requestOptions, 'application/json');
        };
        /**
         * Delete label from a check.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteChecksIDLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ChecksAPI.prototype.deleteChecksIDLabelsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/checks/" + request.checkID + "/labels/" + request.labelID, request, requestOptions);
        };
        /**
         * Get a check query.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetChecksIDQuery }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ChecksAPI.prototype.getChecksIDQuery = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/checks/" + request.checkID + "/query", request, requestOptions);
        };
        return ChecksAPI;
    }());

    /**
     * Dashboards API
     */
    var DashboardsAPI = /** @class */ (function () {
        /**
         * Creates DashboardsAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function DashboardsAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Get all dashboards.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetDashboards }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.getDashboards = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/dashboards" + this.base.queryString(request, [
                'offset',
                'limit',
                'descending',
                'owner',
                'sortBy',
                'id',
                'orgID',
                'org',
            ]), request, requestOptions);
        };
        /**
         * Create a dashboard.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostDashboards }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.postDashboards = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/dashboards", request, requestOptions, 'application/json');
        };
        /**
         * Get a Dashboard.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetDashboardsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.getDashboardsID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/dashboards/" + request.dashboardID + this.base.queryString(request, ['include']), request, requestOptions);
        };
        /**
         * Update a dashboard.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PatchDashboardsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.patchDashboardsID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/dashboards/" + request.dashboardID, request, requestOptions, 'application/json');
        };
        /**
         * Delete a dashboard.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteDashboardsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.deleteDashboardsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/dashboards/" + request.dashboardID, request, requestOptions);
        };
        /**
         * Create a dashboard cell.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostDashboardsIDCells }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.postDashboardsIDCells = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/dashboards/" + request.dashboardID + "/cells", request, requestOptions, 'application/json');
        };
        /**
         * Replace cells in a dashboard.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PutDashboardsIDCells }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.putDashboardsIDCells = function (request, requestOptions) {
            return this.base.request('PUT', "/api/v2/dashboards/" + request.dashboardID + "/cells", request, requestOptions, 'application/json');
        };
        /**
         * Update the non-positional information related to a cell.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PatchDashboardsIDCellsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.patchDashboardsIDCellsID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/dashboards/" + request.dashboardID + "/cells/" + request.cellID, request, requestOptions, 'application/json');
        };
        /**
         * Delete a dashboard cell.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteDashboardsIDCellsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.deleteDashboardsIDCellsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/dashboards/" + request.dashboardID + "/cells/" + request.cellID, request, requestOptions);
        };
        /**
         * Retrieve the view for a cell.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetDashboardsIDCellsIDView }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.getDashboardsIDCellsIDView = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/dashboards/" + request.dashboardID + "/cells/" + request.cellID + "/view", request, requestOptions);
        };
        /**
         * Update the view for a cell.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PatchDashboardsIDCellsIDView }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.patchDashboardsIDCellsIDView = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/dashboards/" + request.dashboardID + "/cells/" + request.cellID + "/view", request, requestOptions, 'application/json');
        };
        /**
         * list all labels for a dashboard.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetDashboardsIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.getDashboardsIDLabels = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/dashboards/" + request.dashboardID + "/labels", request, requestOptions);
        };
        /**
         * Add a label to a dashboard.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostDashboardsIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.postDashboardsIDLabels = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/dashboards/" + request.dashboardID + "/labels", request, requestOptions, 'application/json');
        };
        /**
         * Delete a label from a dashboard.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteDashboardsIDLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.deleteDashboardsIDLabelsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/dashboards/" + request.dashboardID + "/labels/" + request.labelID, request, requestOptions);
        };
        /**
         * List all dashboard members.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetDashboardsIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.getDashboardsIDMembers = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/dashboards/" + request.dashboardID + "/members", request, requestOptions);
        };
        /**
         * Add a member to a dashboard.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostDashboardsIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.postDashboardsIDMembers = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/dashboards/" + request.dashboardID + "/members", request, requestOptions, 'application/json');
        };
        /**
         * Remove a member from a dashboard.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteDashboardsIDMembersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.deleteDashboardsIDMembersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/dashboards/" + request.dashboardID + "/members/" + request.userID, request, requestOptions);
        };
        /**
         * List all dashboard owners.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetDashboardsIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.getDashboardsIDOwners = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/dashboards/" + request.dashboardID + "/owners", request, requestOptions);
        };
        /**
         * Add an owner to a dashboard.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostDashboardsIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.postDashboardsIDOwners = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/dashboards/" + request.dashboardID + "/owners", request, requestOptions, 'application/json');
        };
        /**
         * Remove an owner from a dashboard.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteDashboardsIDOwnersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DashboardsAPI.prototype.deleteDashboardsIDOwnersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/dashboards/" + request.dashboardID + "/owners/" + request.userID, request, requestOptions);
        };
        return DashboardsAPI;
    }());

    /**
     * Dbrps API
     */
    var DbrpsAPI = /** @class */ (function () {
        /**
         * Creates DbrpsAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function DbrpsAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all database retention policy mappings.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetDBRPs }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DbrpsAPI.prototype.getDBRPs = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/dbrps" + this.base.queryString(request, [
                'orgID',
                'id',
                'bucketID',
                'default',
                'db',
                'rp',
            ]), request, requestOptions);
        };
        /**
         * Add a database retention policy mapping.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostDBRP }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DbrpsAPI.prototype.postDBRP = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/dbrps", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a database retention policy mapping.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetDBRPsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DbrpsAPI.prototype.getDBRPsID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/dbrps/" + request.dbrpID + this.base.queryString(request, [
                'orgID',
            ]), request, requestOptions);
        };
        /**
         * Update a database retention policy mapping.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PatchDBRPID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DbrpsAPI.prototype.patchDBRPID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/dbrps/" + request.dbrpID + this.base.queryString(request, [
                'orgID',
            ]), request, requestOptions, 'application/json');
        };
        /**
         * Delete a database retention policy.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteDBRPID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DbrpsAPI.prototype.deleteDBRPID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/dbrps/" + request.dbrpID + this.base.queryString(request, [
                'orgID',
            ]), request, requestOptions);
        };
        return DbrpsAPI;
    }());

    /**
     * Delete API
     */
    var DeleteAPI = /** @class */ (function () {
        /**
         * Creates DeleteAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function DeleteAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Delete time series data from InfluxDB.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostDelete }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DeleteAPI.prototype.postDelete = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/delete" + this.base.queryString(request, [
                'org',
                'bucket',
                'orgID',
                'bucketID',
            ]), request, requestOptions, 'application/json');
        };
        return DeleteAPI;
    }());

    /**
     * Documents API
     */
    var DocumentsAPI = /** @class */ (function () {
        /**
         * Creates DocumentsAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function DocumentsAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetDocumentsTemplates }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DocumentsAPI.prototype.getDocumentsTemplates = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/documents/templates" + this.base.queryString(request, [
                'org',
                'orgID',
            ]), request, requestOptions);
        };
        /**
         * Create a template.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostDocumentsTemplates }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DocumentsAPI.prototype.postDocumentsTemplates = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/documents/templates", request, requestOptions, 'application/json');
        };
        /**
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetDocumentsTemplatesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DocumentsAPI.prototype.getDocumentsTemplatesID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/documents/templates/" + request.templateID, request, requestOptions);
        };
        /**
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PutDocumentsTemplatesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DocumentsAPI.prototype.putDocumentsTemplatesID = function (request, requestOptions) {
            return this.base.request('PUT', "/api/v2/documents/templates/" + request.templateID, request, requestOptions, 'application/json');
        };
        /**
         * Delete a template.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteDocumentsTemplatesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DocumentsAPI.prototype.deleteDocumentsTemplatesID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/documents/templates/" + request.templateID, request, requestOptions);
        };
        /**
         * List all labels for a template.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetDocumentsTemplatesIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DocumentsAPI.prototype.getDocumentsTemplatesIDLabels = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/documents/templates/" + request.templateID + "/labels", request, requestOptions);
        };
        /**
         * Add a label to a template.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostDocumentsTemplatesIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DocumentsAPI.prototype.postDocumentsTemplatesIDLabels = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/documents/templates/" + request.templateID + "/labels", request, requestOptions, 'application/json');
        };
        /**
         * Delete a label from a template.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteDocumentsTemplatesIDLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        DocumentsAPI.prototype.deleteDocumentsTemplatesIDLabelsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/documents/templates/" + request.templateID + "/labels/" + request.labelID, request, requestOptions);
        };
        return DocumentsAPI;
    }());

    /**
     * Flags API
     */
    var FlagsAPI = /** @class */ (function () {
        /**
         * Creates FlagsAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function FlagsAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Return the feature flags for the currently authenticated user.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetFlags }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        FlagsAPI.prototype.getFlags = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/flags", request, requestOptions);
        };
        return FlagsAPI;
    }());

    /**
     * Health API
     */
    var HealthAPI = /** @class */ (function () {
        /**
         * Creates HealthAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function HealthAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Get the health of an instance.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetHealth }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        HealthAPI.prototype.getHealth = function (request, requestOptions) {
            return this.base.request('GET', "/health", request, requestOptions);
        };
        return HealthAPI;
    }());

    /**
     * Labels API
     */
    var LabelsAPI = /** @class */ (function () {
        /**
         * Creates LabelsAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function LabelsAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Get all labels.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        LabelsAPI.prototype.getLabels = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/labels" + this.base.queryString(request, ['orgID']), request, requestOptions);
        };
        /**
         * Create a label.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        LabelsAPI.prototype.postLabels = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/labels", request, requestOptions, 'application/json');
        };
        /**
         * Get a label.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        LabelsAPI.prototype.getLabelsID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/labels/" + request.labelID, request, requestOptions);
        };
        /**
         * Update a label.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PatchLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        LabelsAPI.prototype.patchLabelsID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/labels/" + request.labelID, request, requestOptions, 'application/json');
        };
        /**
         * Delete a label.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        LabelsAPI.prototype.deleteLabelsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/labels/" + request.labelID, request, requestOptions);
        };
        return LabelsAPI;
    }());

    /**
     * Me API
     */
    var MeAPI = /** @class */ (function () {
        /**
         * Creates MeAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function MeAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Return the current authenticated user.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetMe }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        MeAPI.prototype.getMe = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/me", request, requestOptions);
        };
        /**
         * Update a password.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PutMePassword }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        MeAPI.prototype.putMePassword = function (request, requestOptions) {
            return this.base.request('PUT', "/api/v2/me/password", request, requestOptions, 'application/json');
        };
        return MeAPI;
    }());

    /**
     * NotificationEndpoints API
     */
    var NotificationEndpointsAPI = /** @class */ (function () {
        /**
         * Creates NotificationEndpointsAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function NotificationEndpointsAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Get all notification endpoints.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetNotificationEndpoints }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationEndpointsAPI.prototype.getNotificationEndpoints = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/notificationEndpoints" + this.base.queryString(request, [
                'offset',
                'limit',
                'orgID',
            ]), request, requestOptions);
        };
        /**
         * Add a notification endpoint.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/CreateNotificationEndpoint }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationEndpointsAPI.prototype.createNotificationEndpoint = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/notificationEndpoints", request, requestOptions, 'application/json');
        };
        /**
         * Get a notification endpoint.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetNotificationEndpointsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationEndpointsAPI.prototype.getNotificationEndpointsID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/notificationEndpoints/" + request.endpointID, request, requestOptions);
        };
        /**
         * Update a notification endpoint.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PutNotificationEndpointsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationEndpointsAPI.prototype.putNotificationEndpointsID = function (request, requestOptions) {
            return this.base.request('PUT', "/api/v2/notificationEndpoints/" + request.endpointID, request, requestOptions, 'application/json');
        };
        /**
         * Update a notification endpoint.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PatchNotificationEndpointsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationEndpointsAPI.prototype.patchNotificationEndpointsID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/notificationEndpoints/" + request.endpointID, request, requestOptions, 'application/json');
        };
        /**
         * Delete a notification endpoint.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteNotificationEndpointsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationEndpointsAPI.prototype.deleteNotificationEndpointsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/notificationEndpoints/" + request.endpointID, request, requestOptions);
        };
        /**
         * List all labels for a notification endpoint.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetNotificationEndpointsIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationEndpointsAPI.prototype.getNotificationEndpointsIDLabels = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/notificationEndpoints/" + request.endpointID + "/labels", request, requestOptions);
        };
        /**
         * Add a label to a notification endpoint.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostNotificationEndpointIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationEndpointsAPI.prototype.postNotificationEndpointIDLabels = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/notificationEndpoints/" + request.endpointID + "/labels", request, requestOptions, 'application/json');
        };
        /**
         * Delete a label from a notification endpoint.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteNotificationEndpointsIDLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationEndpointsAPI.prototype.deleteNotificationEndpointsIDLabelsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/notificationEndpoints/" + request.endpointID + "/labels/" + request.labelID, request, requestOptions);
        };
        return NotificationEndpointsAPI;
    }());

    /**
     * NotificationRules API
     */
    var NotificationRulesAPI = /** @class */ (function () {
        /**
         * Creates NotificationRulesAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function NotificationRulesAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Get all notification rules.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetNotificationRules }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationRulesAPI.prototype.getNotificationRules = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/notificationRules" + this.base.queryString(request, [
                'offset',
                'limit',
                'orgID',
                'checkID',
                'tag',
            ]), request, requestOptions);
        };
        /**
         * Add a notification rule.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/CreateNotificationRule }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationRulesAPI.prototype.createNotificationRule = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/notificationRules", request, requestOptions, 'application/json');
        };
        /**
         * Get a notification rule.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetNotificationRulesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationRulesAPI.prototype.getNotificationRulesID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/notificationRules/" + request.ruleID, request, requestOptions);
        };
        /**
         * Update a notification rule.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PutNotificationRulesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationRulesAPI.prototype.putNotificationRulesID = function (request, requestOptions) {
            return this.base.request('PUT', "/api/v2/notificationRules/" + request.ruleID, request, requestOptions, 'application/json');
        };
        /**
         * Update a notification rule.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PatchNotificationRulesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationRulesAPI.prototype.patchNotificationRulesID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/notificationRules/" + request.ruleID, request, requestOptions, 'application/json');
        };
        /**
         * Delete a notification rule.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteNotificationRulesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationRulesAPI.prototype.deleteNotificationRulesID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/notificationRules/" + request.ruleID, request, requestOptions);
        };
        /**
         * List all labels for a notification rule.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetNotificationRulesIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationRulesAPI.prototype.getNotificationRulesIDLabels = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/notificationRules/" + request.ruleID + "/labels", request, requestOptions);
        };
        /**
         * Add a label to a notification rule.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostNotificationRuleIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationRulesAPI.prototype.postNotificationRuleIDLabels = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/notificationRules/" + request.ruleID + "/labels", request, requestOptions, 'application/json');
        };
        /**
         * Delete label from a notification rule.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteNotificationRulesIDLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationRulesAPI.prototype.deleteNotificationRulesIDLabelsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/notificationRules/" + request.ruleID + "/labels/" + request.labelID, request, requestOptions);
        };
        /**
         * Get a notification rule query.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetNotificationRulesIDQuery }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        NotificationRulesAPI.prototype.getNotificationRulesIDQuery = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/notificationRules/" + request.ruleID + "/query", request, requestOptions);
        };
        return NotificationRulesAPI;
    }());

    /**
     * Orgs API
     */
    var OrgsAPI = /** @class */ (function () {
        /**
         * Creates OrgsAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function OrgsAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all organizations.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetOrgs }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.getOrgs = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/orgs" + this.base.queryString(request, [
                'offset',
                'limit',
                'descending',
                'org',
                'orgID',
                'userID',
            ]), request, requestOptions);
        };
        /**
         * Create an organization.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostOrgs }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.postOrgs = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/orgs", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve an organization.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetOrgsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.getOrgsID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/orgs/" + request.orgID, request, requestOptions);
        };
        /**
         * Update an organization.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PatchOrgsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.patchOrgsID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/orgs/" + request.orgID, request, requestOptions, 'application/json');
        };
        /**
         * Delete an organization.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteOrgsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.deleteOrgsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/orgs/" + request.orgID, request, requestOptions);
        };
        /**
         * List all secret keys for an organization.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetOrgsIDSecrets }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.getOrgsIDSecrets = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/orgs/" + request.orgID + "/secrets", request, requestOptions);
        };
        /**
         * Update secrets in an organization.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PatchOrgsIDSecrets }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.patchOrgsIDSecrets = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/orgs/" + request.orgID + "/secrets", request, requestOptions, 'application/json');
        };
        /**
         * Delete secrets from an organization.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostOrgsIDSecrets }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.postOrgsIDSecrets = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/orgs/" + request.orgID + "/secrets/delete", request, requestOptions, 'application/json');
        };
        /**
         * List all members of an organization.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetOrgsIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.getOrgsIDMembers = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/orgs/" + request.orgID + "/members", request, requestOptions);
        };
        /**
         * Add a member to an organization.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostOrgsIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.postOrgsIDMembers = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/orgs/" + request.orgID + "/members", request, requestOptions, 'application/json');
        };
        /**
         * Remove a member from an organization.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteOrgsIDMembersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.deleteOrgsIDMembersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/orgs/" + request.orgID + "/members/" + request.userID, request, requestOptions);
        };
        /**
         * List all owners of an organization.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetOrgsIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.getOrgsIDOwners = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/orgs/" + request.orgID + "/owners", request, requestOptions);
        };
        /**
         * Add an owner to an organization.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostOrgsIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.postOrgsIDOwners = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/orgs/" + request.orgID + "/owners", request, requestOptions, 'application/json');
        };
        /**
         * Remove an owner from an organization.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteOrgsIDOwnersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        OrgsAPI.prototype.deleteOrgsIDOwnersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/orgs/" + request.orgID + "/owners/" + request.userID, request, requestOptions);
        };
        return OrgsAPI;
    }());

    /**
     * Query API
     */
    var QueryAPI = /** @class */ (function () {
        /**
         * Creates QueryAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function QueryAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostQueryAst }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        QueryAPI.prototype.postQueryAst = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/query/ast", request, requestOptions, 'application/json');
        };
        /**
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetQuerySuggestions }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        QueryAPI.prototype.getQuerySuggestions = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/query/suggestions", request, requestOptions);
        };
        /**
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetQuerySuggestionsName }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        QueryAPI.prototype.getQuerySuggestionsName = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/query/suggestions/" + request.name, request, requestOptions);
        };
        /**
         * Analyze an InfluxQL or Flux query.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostQueryAnalyze }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        QueryAPI.prototype.postQueryAnalyze = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/query/analyze", request, requestOptions, 'application/json');
        };
        /**
         * Query InfluxDB.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostQuery }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        QueryAPI.prototype.postQuery = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/query" + this.base.queryString(request, ['org', 'orgID']), request, requestOptions, 'application/json');
        };
        return QueryAPI;
    }());

    /**
     * Ready API
     */
    var ReadyAPI = /** @class */ (function () {
        /**
         * Creates ReadyAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function ReadyAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Get the readiness of an instance at startup.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetReady }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ReadyAPI.prototype.getReady = function (request, requestOptions) {
            return this.base.request('GET', "/ready", request, requestOptions);
        };
        return ReadyAPI;
    }());

    /**
     * Scrapers API
     */
    var ScrapersAPI = /** @class */ (function () {
        /**
         * Creates ScrapersAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function ScrapersAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Get all scraper targets.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetScrapers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.getScrapers = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/scrapers" + this.base.queryString(request, [
                'name',
                'id',
                'orgID',
                'org',
            ]), request, requestOptions);
        };
        /**
         * Create a scraper target.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostScrapers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.postScrapers = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/scrapers", request, requestOptions, 'application/json');
        };
        /**
         * Get a scraper target by ID.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetScrapersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.getScrapersID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/scrapers/" + request.scraperTargetID, request, requestOptions);
        };
        /**
         * Update a scraper target.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PatchScrapersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.patchScrapersID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/scrapers/" + request.scraperTargetID, request, requestOptions, 'application/json');
        };
        /**
         * Delete a scraper target.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteScrapersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.deleteScrapersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/scrapers/" + request.scraperTargetID, request, requestOptions);
        };
        /**
         * List all labels for a scraper target.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetScrapersIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.getScrapersIDLabels = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/scrapers/" + request.scraperTargetID + "/labels", request, requestOptions);
        };
        /**
         * Add a label to a scraper target.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostScrapersIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.postScrapersIDLabels = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/scrapers/" + request.scraperTargetID + "/labels", request, requestOptions, 'application/json');
        };
        /**
         * Delete a label from a scraper target.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteScrapersIDLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.deleteScrapersIDLabelsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/scrapers/" + request.scraperTargetID + "/labels/" + request.labelID, request, requestOptions);
        };
        /**
         * List all users with member privileges for a scraper target.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetScrapersIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.getScrapersIDMembers = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/scrapers/" + request.scraperTargetID + "/members", request, requestOptions);
        };
        /**
         * Add a member to a scraper target.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostScrapersIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.postScrapersIDMembers = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/scrapers/" + request.scraperTargetID + "/members", request, requestOptions, 'application/json');
        };
        /**
         * Remove a member from a scraper target.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteScrapersIDMembersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.deleteScrapersIDMembersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/scrapers/" + request.scraperTargetID + "/members/" + request.userID, request, requestOptions);
        };
        /**
         * List all owners of a scraper target.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetScrapersIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.getScrapersIDOwners = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/scrapers/" + request.scraperTargetID + "/owners", request, requestOptions);
        };
        /**
         * Add an owner to a scraper target.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostScrapersIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.postScrapersIDOwners = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/scrapers/" + request.scraperTargetID + "/owners", request, requestOptions, 'application/json');
        };
        /**
         * Remove an owner from a scraper target.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteScrapersIDOwnersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        ScrapersAPI.prototype.deleteScrapersIDOwnersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/scrapers/" + request.scraperTargetID + "/owners/" + request.userID, request, requestOptions);
        };
        return ScrapersAPI;
    }());

    /**
     * Setup API
     */
    var SetupAPI = /** @class */ (function () {
        /**
         * Creates SetupAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function SetupAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Check if database has default user, org, bucket.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetSetup }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SetupAPI.prototype.getSetup = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/setup", request, requestOptions);
        };
        /**
         * Set up initial user, org and bucket.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostSetup }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SetupAPI.prototype.postSetup = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/setup", request, requestOptions, 'application/json');
        };
        /**
         * Set up a new user, org and bucket.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostSetupUser }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SetupAPI.prototype.postSetupUser = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/setup/user", request, requestOptions, 'application/json');
        };
        return SetupAPI;
    }());

    /**
     * Signin API
     */
    var SigninAPI = /** @class */ (function () {
        /**
         * Creates SigninAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function SigninAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Exchange basic auth credentials for session.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostSignin }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SigninAPI.prototype.postSignin = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/signin", request, requestOptions);
        };
        return SigninAPI;
    }());

    /**
     * Signout API
     */
    var SignoutAPI = /** @class */ (function () {
        /**
         * Creates SignoutAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function SignoutAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Expire the current session.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostSignout }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SignoutAPI.prototype.postSignout = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/signout", request, requestOptions);
        };
        return SignoutAPI;
    }());

    /**
     * Sources API
     */
    var SourcesAPI = /** @class */ (function () {
        /**
         * Creates SourcesAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function SourcesAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Get all sources.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetSources }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SourcesAPI.prototype.getSources = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/sources" + this.base.queryString(request, ['org']), request, requestOptions);
        };
        /**
         * Creates a source.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostSources }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SourcesAPI.prototype.postSources = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/sources", request, requestOptions, 'application/json');
        };
        /**
         * Get a source.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetSourcesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SourcesAPI.prototype.getSourcesID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/sources/" + request.sourceID, request, requestOptions);
        };
        /**
         * Update a Source.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PatchSourcesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SourcesAPI.prototype.patchSourcesID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/sources/" + request.sourceID, request, requestOptions, 'application/json');
        };
        /**
         * Delete a source.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteSourcesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SourcesAPI.prototype.deleteSourcesID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/sources/" + request.sourceID, request, requestOptions);
        };
        /**
         * Get the health of a source.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetSourcesIDHealth }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SourcesAPI.prototype.getSourcesIDHealth = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/sources/" + request.sourceID + "/health", request, requestOptions);
        };
        /**
         * Get buckets in a source.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetSourcesIDBuckets }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        SourcesAPI.prototype.getSourcesIDBuckets = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/sources/" + request.sourceID + "/buckets" + this.base.queryString(request, ['org']), request, requestOptions);
        };
        return SourcesAPI;
    }());

    /**
     * Stacks API
     */
    var StacksAPI = /** @class */ (function () {
        /**
         * Creates StacksAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function StacksAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Grab a list of installed InfluxDB Templates.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/ListStacks }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        StacksAPI.prototype.listStacks = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/stacks" + this.base.queryString(request, [
                'orgID',
                'name',
                'stackID',
            ]), request, requestOptions);
        };
        /**
         * Create a new stack.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/CreateStack }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        StacksAPI.prototype.createStack = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/stacks", request, requestOptions, 'application/json');
        };
        /**
         * Grab a stack by its ID.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/ReadStack }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        StacksAPI.prototype.readStack = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/stacks/" + request.stack_id, request, requestOptions);
        };
        /**
         * Update an InfluxDB Stack.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/UpdateStack }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        StacksAPI.prototype.updateStack = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/stacks/" + request.stack_id, request, requestOptions, 'application/json');
        };
        /**
         * Delete a stack and remove all its associated resources.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteStack }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        StacksAPI.prototype.deleteStack = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/stacks/" + request.stack_id + this.base.queryString(request, [
                'orgID',
            ]), request, requestOptions);
        };
        /**
         * Uninstall an InfluxDB Stack.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/UninstallStack }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        StacksAPI.prototype.uninstallStack = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/stacks/" + request.stack_id + "/uninstall", request, requestOptions);
        };
        return StacksAPI;
    }());

    /**
     * Tasks API
     */
    var TasksAPI = /** @class */ (function () {
        /**
         * Creates TasksAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function TasksAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all tasks.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetTasks }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.getTasks = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/tasks" + this.base.queryString(request, [
                'name',
                'after',
                'user',
                'org',
                'orgID',
                'status',
                'limit',
            ]), request, requestOptions);
        };
        /**
         * Create a new task.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostTasks }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.postTasks = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/tasks", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a task.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetTasksID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.getTasksID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/tasks/" + request.taskID, request, requestOptions);
        };
        /**
         * Update a task.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PatchTasksID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.patchTasksID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/tasks/" + request.taskID, request, requestOptions, 'application/json');
        };
        /**
         * Delete a task.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteTasksID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.deleteTasksID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/tasks/" + request.taskID, request, requestOptions);
        };
        /**
         * List runs for a task.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetTasksIDRuns }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.getTasksIDRuns = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/tasks/" + request.taskID + "/runs" + this.base.queryString(request, [
                'after',
                'limit',
                'afterTime',
                'beforeTime',
            ]), request, requestOptions);
        };
        /**
         * Manually start a task run, overriding the current schedule.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostTasksIDRuns }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.postTasksIDRuns = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/tasks/" + request.taskID + "/runs", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a single run for a task.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetTasksIDRunsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.getTasksIDRunsID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/tasks/" + request.taskID + "/runs/" + request.runID, request, requestOptions);
        };
        /**
         * Cancel a running task.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteTasksIDRunsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.deleteTasksIDRunsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/tasks/" + request.taskID + "/runs/" + request.runID, request, requestOptions);
        };
        /**
         * Retry a task run.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostTasksIDRunsIDRetry }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.postTasksIDRunsIDRetry = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/tasks/" + request.taskID + "/runs/" + request.runID + "/retry", request, requestOptions);
        };
        /**
         * Retrieve all logs for a task.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetTasksIDLogs }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.getTasksIDLogs = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/tasks/" + request.taskID + "/logs", request, requestOptions);
        };
        /**
         * Retrieve all logs for a run.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetTasksIDRunsIDLogs }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.getTasksIDRunsIDLogs = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/tasks/" + request.taskID + "/runs/" + request.runID + "/logs", request, requestOptions);
        };
        /**
         * List all labels for a task.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetTasksIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.getTasksIDLabels = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/tasks/" + request.taskID + "/labels", request, requestOptions);
        };
        /**
         * Add a label to a task.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostTasksIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.postTasksIDLabels = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/tasks/" + request.taskID + "/labels", request, requestOptions, 'application/json');
        };
        /**
         * Delete a label from a task.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteTasksIDLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.deleteTasksIDLabelsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/tasks/" + request.taskID + "/labels/" + request.labelID, request, requestOptions);
        };
        /**
         * List all task members.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetTasksIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.getTasksIDMembers = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/tasks/" + request.taskID + "/members", request, requestOptions);
        };
        /**
         * Add a member to a task.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostTasksIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.postTasksIDMembers = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/tasks/" + request.taskID + "/members", request, requestOptions, 'application/json');
        };
        /**
         * Remove a member from a task.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteTasksIDMembersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.deleteTasksIDMembersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/tasks/" + request.taskID + "/members/" + request.userID, request, requestOptions);
        };
        /**
         * List all owners of a task.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetTasksIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.getTasksIDOwners = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/tasks/" + request.taskID + "/owners", request, requestOptions);
        };
        /**
         * Add an owner to a task.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostTasksIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.postTasksIDOwners = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/tasks/" + request.taskID + "/owners", request, requestOptions, 'application/json');
        };
        /**
         * Remove an owner from a task.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteTasksIDOwnersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TasksAPI.prototype.deleteTasksIDOwnersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/tasks/" + request.taskID + "/owners/" + request.userID, request, requestOptions);
        };
        return TasksAPI;
    }());

    /**
     * Telegraf API
     */
    var TelegrafAPI = /** @class */ (function () {
        /**
         * Creates TelegrafAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function TelegrafAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetTelegrafPlugins }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafAPI.prototype.getTelegrafPlugins = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/telegraf/plugins" + this.base.queryString(request, ['type']), request, requestOptions);
        };
        return TelegrafAPI;
    }());

    /**
     * Telegrafs API
     */
    var TelegrafsAPI = /** @class */ (function () {
        /**
         * Creates TelegrafsAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function TelegrafsAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetTelegrafs }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.getTelegrafs = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/telegrafs" + this.base.queryString(request, ['orgID']), request, requestOptions);
        };
        /**
         * Create a Telegraf config.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostTelegrafs }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.postTelegrafs = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/telegrafs", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a Telegraf config.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetTelegrafsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.getTelegrafsID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/telegrafs/" + request.telegrafID, request, requestOptions);
        };
        /**
         * Update a Telegraf config.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PutTelegrafsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.putTelegrafsID = function (request, requestOptions) {
            return this.base.request('PUT', "/api/v2/telegrafs/" + request.telegrafID, request, requestOptions, 'application/json');
        };
        /**
         * Delete a Telegraf config.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteTelegrafsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.deleteTelegrafsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/telegrafs/" + request.telegrafID, request, requestOptions);
        };
        /**
         * List all labels for a Telegraf config.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetTelegrafsIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.getTelegrafsIDLabels = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/telegrafs/" + request.telegrafID + "/labels", request, requestOptions);
        };
        /**
         * Add a label to a Telegraf config.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostTelegrafsIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.postTelegrafsIDLabels = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/telegrafs/" + request.telegrafID + "/labels", request, requestOptions, 'application/json');
        };
        /**
         * Delete a label from a Telegraf config.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteTelegrafsIDLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.deleteTelegrafsIDLabelsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/telegrafs/" + request.telegrafID + "/labels/" + request.labelID, request, requestOptions);
        };
        /**
         * List all users with member privileges for a Telegraf config.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetTelegrafsIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.getTelegrafsIDMembers = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/telegrafs/" + request.telegrafID + "/members", request, requestOptions);
        };
        /**
         * Add a member to a Telegraf config.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostTelegrafsIDMembers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.postTelegrafsIDMembers = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/telegrafs/" + request.telegrafID + "/members", request, requestOptions, 'application/json');
        };
        /**
         * Remove a member from a Telegraf config.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteTelegrafsIDMembersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.deleteTelegrafsIDMembersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/telegrafs/" + request.telegrafID + "/members/" + request.userID, request, requestOptions);
        };
        /**
         * List all owners of a Telegraf config.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetTelegrafsIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.getTelegrafsIDOwners = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/telegrafs/" + request.telegrafID + "/owners", request, requestOptions);
        };
        /**
         * Add an owner to a Telegraf config.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostTelegrafsIDOwners }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.postTelegrafsIDOwners = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/telegrafs/" + request.telegrafID + "/owners", request, requestOptions, 'application/json');
        };
        /**
         * Remove an owner from a Telegraf config.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteTelegrafsIDOwnersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TelegrafsAPI.prototype.deleteTelegrafsIDOwnersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/telegrafs/" + request.telegrafID + "/owners/" + request.userID, request, requestOptions);
        };
        return TelegrafsAPI;
    }());

    /**
     * Templates API
     */
    var TemplatesAPI = /** @class */ (function () {
        /**
         * Creates TemplatesAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function TemplatesAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Apply or dry-run an InfluxDB Template.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/ApplyTemplate }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TemplatesAPI.prototype.applyTemplate = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/templates/apply", request, requestOptions, 'application/json');
        };
        /**
         * Export a new Influx Template.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/ExportTemplate }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        TemplatesAPI.prototype.exportTemplate = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/templates/export", request, requestOptions, 'application/json');
        };
        return TemplatesAPI;
    }());

    /**
     * Users API
     */
    var UsersAPI = /** @class */ (function () {
        /**
         * Creates UsersAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function UsersAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * List all users.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetUsers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        UsersAPI.prototype.getUsers = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/users", request, requestOptions);
        };
        /**
         * Create a user.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostUsers }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        UsersAPI.prototype.postUsers = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/users", request, requestOptions, 'application/json');
        };
        /**
         * Retrieve a user.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetUsersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        UsersAPI.prototype.getUsersID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/users/" + request.userID, request, requestOptions);
        };
        /**
         * Update a user.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PatchUsersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        UsersAPI.prototype.patchUsersID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/users/" + request.userID, request, requestOptions, 'application/json');
        };
        /**
         * Delete a user.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteUsersID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        UsersAPI.prototype.deleteUsersID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/users/" + request.userID, request, requestOptions);
        };
        /**
         * Update a password.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostUsersIDPassword }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        UsersAPI.prototype.postUsersIDPassword = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/users/" + request.userID + "/password", request, requestOptions, 'application/json');
        };
        return UsersAPI;
    }());

    /**
     * Variables API
     */
    var VariablesAPI = /** @class */ (function () {
        /**
         * Creates VariablesAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function VariablesAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Get all variables.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetVariables }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        VariablesAPI.prototype.getVariables = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/variables" + this.base.queryString(request, ['org', 'orgID']), request, requestOptions);
        };
        /**
         * Create a variable.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostVariables }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        VariablesAPI.prototype.postVariables = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/variables", request, requestOptions, 'application/json');
        };
        /**
         * Get a variable.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetVariablesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        VariablesAPI.prototype.getVariablesID = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/variables/" + request.variableID, request, requestOptions);
        };
        /**
         * Replace a variable.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PutVariablesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        VariablesAPI.prototype.putVariablesID = function (request, requestOptions) {
            return this.base.request('PUT', "/api/v2/variables/" + request.variableID, request, requestOptions, 'application/json');
        };
        /**
         * Update a variable.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PatchVariablesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        VariablesAPI.prototype.patchVariablesID = function (request, requestOptions) {
            return this.base.request('PATCH', "/api/v2/variables/" + request.variableID, request, requestOptions, 'application/json');
        };
        /**
         * Delete a variable.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteVariablesID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        VariablesAPI.prototype.deleteVariablesID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/variables/" + request.variableID, request, requestOptions);
        };
        /**
         * List all labels for a variable.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/GetVariablesIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        VariablesAPI.prototype.getVariablesIDLabels = function (request, requestOptions) {
            return this.base.request('GET', "/api/v2/variables/" + request.variableID + "/labels", request, requestOptions);
        };
        /**
         * Add a label to a variable.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostVariablesIDLabels }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        VariablesAPI.prototype.postVariablesIDLabels = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/variables/" + request.variableID + "/labels", request, requestOptions, 'application/json');
        };
        /**
         * Delete a label from a variable.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/DeleteVariablesIDLabelsID }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        VariablesAPI.prototype.deleteVariablesIDLabelsID = function (request, requestOptions) {
            return this.base.request('DELETE', "/api/v2/variables/" + request.variableID + "/labels/" + request.labelID, request, requestOptions);
        };
        return VariablesAPI;
    }());

    /**
     * Write API
     */
    var WriteAPI = /** @class */ (function () {
        /**
         * Creates WriteAPI
         * @param influxDB - an instance that knows how to communicate with InfluxDB server
         */
        function WriteAPI(influxDB) {
            this.base = new APIBase(influxDB);
        }
        /**
         * Write time series data into InfluxDB.
         * See {@link https://v2.docs.influxdata.com/v2.0/api/#operation/PostWrite }
         * @param request - request parameters and body (if supported)
         * @param requestOptions - optional transport options
         * @returns promise of response
         */
        WriteAPI.prototype.postWrite = function (request, requestOptions) {
            return this.base.request('POST', "/api/v2/write" + this.base.queryString(request, [
                'org',
                'orgID',
                'bucket',
                'precision',
            ]), request, requestOptions, 'text/plain');
        };
        return WriteAPI;
    }());

    exports.AuthorizationsAPI = AuthorizationsAPI;
    exports.BucketsAPI = BucketsAPI;
    exports.ChecksAPI = ChecksAPI;
    exports.DashboardsAPI = DashboardsAPI;
    exports.DbrpsAPI = DbrpsAPI;
    exports.DeleteAPI = DeleteAPI;
    exports.DocumentsAPI = DocumentsAPI;
    exports.FlagsAPI = FlagsAPI;
    exports.HealthAPI = HealthAPI;
    exports.LabelsAPI = LabelsAPI;
    exports.MeAPI = MeAPI;
    exports.NotificationEndpointsAPI = NotificationEndpointsAPI;
    exports.NotificationRulesAPI = NotificationRulesAPI;
    exports.OrgsAPI = OrgsAPI;
    exports.QueryAPI = QueryAPI;
    exports.ReadyAPI = ReadyAPI;
    exports.RootAPI = RootAPI;
    exports.ScrapersAPI = ScrapersAPI;
    exports.SetupAPI = SetupAPI;
    exports.SigninAPI = SigninAPI;
    exports.SignoutAPI = SignoutAPI;
    exports.SourcesAPI = SourcesAPI;
    exports.StacksAPI = StacksAPI;
    exports.TasksAPI = TasksAPI;
    exports.TelegrafAPI = TelegrafAPI;
    exports.TelegrafsAPI = TelegrafsAPI;
    exports.TemplatesAPI = TemplatesAPI;
    exports.UsersAPI = UsersAPI;
    exports.VariablesAPI = VariablesAPI;
    exports.WriteAPI = WriteAPI;

    return exports;

}({}));
//# sourceMappingURL=influxdbApis.js.map
