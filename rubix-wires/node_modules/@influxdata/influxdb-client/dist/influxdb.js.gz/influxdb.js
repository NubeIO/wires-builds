var influxdb = (function (exports) {
    'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    /** default connection options */
    var DEFAULT_ConnectionOptions = {
        timeout: 10000,
    };
    /** default RetryDelayStrategyOptions */
    var DEFAULT_RetryDelayStrategyOptions = Object.freeze({
        retryJitter: 200,
        minRetryDelay: 5000,
        maxRetryDelay: 180000,
        exponentialBase: 5,
    });
    /** default writeOptions */
    var DEFAULT_WriteOptions = Object.freeze(__assign({ batchSize: 1000, flushInterval: 60000, writeFailed: function () { }, maxRetries: 3, maxBufferLines: 32000 }, DEFAULT_RetryDelayStrategyOptions));

    var retriableStatusCodes = [404, 408, 425, 429, 500, 502, 503, 504];
    /** isStatusCodeRetriable checks whether the supplied HTTP status code is retriable. */
    function isStatusCodeRetriable(statusCode) {
        return retriableStatusCodes.includes(statusCode);
    }
    /** IllegalArgumentError is thrown when illegal argument is supplied. */
    var IllegalArgumentError = /** @class */ (function (_super) {
        __extends(IllegalArgumentError, _super);
        /* istanbul ignore next */
        function IllegalArgumentError(message) {
            var _this = _super.call(this, message) || this;
            Object.setPrototypeOf(_this, IllegalArgumentError.prototype);
            return _this;
        }
        return IllegalArgumentError;
    }(Error));
    /**
     * A general HTTP error.
     */
    var HttpError = /** @class */ (function (_super) {
        __extends(HttpError, _super);
        /* istanbul ignore next because of super() not being covered*/
        function HttpError(statusCode, statusMessage, body, retryAfter) {
            var _this = _super.call(this) || this;
            _this.statusCode = statusCode;
            _this.statusMessage = statusMessage;
            _this.body = body;
            Object.setPrototypeOf(_this, HttpError.prototype);
            if (body) {
                _this.message = statusCode + " " + statusMessage + " : " + body;
            }
            else {
                _this.message = statusCode + " " + statusMessage;
            }
            _this.setRetryAfter(retryAfter);
            return _this;
        }
        HttpError.prototype.setRetryAfter = function (retryAfter) {
            if (typeof retryAfter === 'string') {
                // try to parse the supplied number as milliseconds
                if (/^[0-9]+$/.test(retryAfter)) {
                    this._retryAfter = parseInt(retryAfter);
                }
                else {
                    this._retryAfter = 0;
                }
            }
            else {
                this._retryAfter = 0;
            }
        };
        HttpError.prototype.canRetry = function () {
            return isStatusCodeRetriable(this.statusCode);
        };
        HttpError.prototype.retryAfter = function () {
            return this._retryAfter;
        };
        return HttpError;
    }(Error));
    //see https://nodejs.org/api/errors.html
    var RETRY_CODES = [
        'ECONNRESET',
        'ENOTFOUND',
        'ESOCKETTIMEDOUT',
        'ETIMEDOUT',
        'ECONNREFUSED',
        'EHOSTUNREACH',
        'EPIPE',
    ];
    /**
     * Tests the error in order to know if an HTTP call can be retried.
     * @param error - error to test
     * @returns true for a retriable error
     */
    function canRetryHttpCall(error) {
        if (!error) {
            return false;
        }
        else if (typeof error.canRetry === 'function') {
            return !!error.canRetry();
        }
        else if (error.code && RETRY_CODES.includes(error.code)) {
            return true;
        }
        return false;
    }
    /**
     * Gets retry delay from the supplied error, possibly using random number up to retryJitter.
     */
    function getRetryDelay(error, retryJitter) {
        if (!error) {
            return 0;
        }
        else {
            var retVal = void 0;
            if (typeof error.retryAfter === 'function') {
                return error.retryAfter();
            }
            else {
                retVal = 0;
            }
            if (retryJitter && retryJitter > 0) {
                return retVal + Math.round(Math.random() * retryJitter);
            }
            else {
                return retVal;
            }
        }
    }
    /** RequestTimedOutError indicates request timeout in the communication with the server */
    var RequestTimedOutError = /** @class */ (function (_super) {
        __extends(RequestTimedOutError, _super);
        /* istanbul ignore next because of super() not being covered */
        function RequestTimedOutError() {
            var _this = _super.call(this) || this;
            Object.setPrototypeOf(_this, RequestTimedOutError.prototype);
            _this.message = 'Request timed out';
            return _this;
        }
        RequestTimedOutError.prototype.canRetry = function () {
            return true;
        };
        RequestTimedOutError.prototype.retryAfter = function () {
            return 0;
        };
        return RequestTimedOutError;
    }(Error));
    /** AbortError indicates that the communication with the server was aborted */
    var AbortError = /** @class */ (function (_super) {
        __extends(AbortError, _super);
        /* istanbul ignore next because of super() not being covered */
        function AbortError() {
            var _this = _super.call(this) || this;
            _this.name = 'AbortError';
            Object.setPrototypeOf(_this, AbortError.prototype);
            _this.message = 'Response aborted';
            return _this;
        }
        AbortError.prototype.canRetry = function () {
            return true;
        };
        AbortError.prototype.retryAfter = function () {
            return 0;
        };
        return AbortError;
    }(Error));

    var reEscape = /[-|\\{()[\]^$+*?.]/g;
    var escapeChar = '\\';
    /**
     * The Escaper escapes the special characters in the provided list
     * with backslashes. Much of the code here is inspired by that in the
     * sqlstring packet found here: https://github.com/mysqljs/sqlstring
     *
     * Instances of the Escaper are derived from the documentation of escape
     * sequences found here: https://aka.ms/co1m4k
     *
     * sqlstring is made available under the following license:
     *
     *   Copyright (c) 2012 Felix Geisendörfer (felix\@debuggable.com) and contributors
     *
     *   Permission is hereby granted, free of charge, to any person obtaining a copy
     *   of this software and associated documentation files (the "Software"), to deal
     *   in the Software without restriction, including without limitation the rights
     *   to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
     *   copies of the Software, and to permit persons to whom the Software is
     *   furnished to do so, subject to the following conditions:
     *
     *   The above copyright notice and this permission notice shall be included in
     *   all copies or substantial portions of the Software.
     *
     *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
     *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
     *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
     *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
     *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
     *   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
     *   THE SOFTWARE.
     *
     */
    var Escaper = /** @class */ (function () {
        function Escaper(config, wrap) {
            if (wrap === void 0) { wrap = ''; }
            this.config = config;
            this.wrap = wrap;
            var patterns = Object.keys(config)
                .join('|')
                .replace(reEscape, '\\$&');
            this._re = new RegExp('[' + patterns + ']', 'g');
        }
        /**
         * Escape replaces occurrences of special characters within the target
         * string with the necessary escape codes.
         */
        Escaper.prototype.escape = function (val) {
            this._re.lastIndex = 0;
            var chunkIndex = this._re.lastIndex;
            var escapedVal = '';
            var match = this._re.exec(val);
            while (match) {
                var matched = match[0];
                var toEscape = this.config[matched].escapeChar;
                var toReplace = this.config[matched].replaceChar;
                escapedVal += val.slice(chunkIndex, match.index);
                escapedVal += toReplace != undefined ? toReplace : toEscape + matched;
                chunkIndex = this._re.lastIndex;
                match = this._re.exec(val);
            }
            if (chunkIndex === 0) {
                return this.wrap + val + this.wrap;
            }
            if (chunkIndex < val.length) {
                return this.wrap + escapedVal + val.slice(chunkIndex) + this.wrap;
            }
            return this.wrap + escapedVal + this.wrap;
        };
        return Escaper;
    }());
    var EscaperConfig = /** @class */ (function () {
        function EscaperConfig(escapeChar, replaceChar) {
            this.escapeChar = escapeChar;
            this.replaceChar = replaceChar;
        }
        return EscaperConfig;
    }());
    var escaperConfig = new EscaperConfig(escapeChar);
    var bindEsc = function (e) { return e.escape.bind(e); };
    /**
     * Provides functions escape specific parts in InfluxDB line protocol.
     */
    var escape = {
        /**
         * Measurement escapes measurement names.
         */
        measurement: bindEsc(new Escaper({
            ',': escaperConfig,
            ' ': escaperConfig,
            '\n': new EscaperConfig(undefined, '\\n'),
            '\r': new EscaperConfig(undefined, '\\r'),
            '\t': new EscaperConfig(undefined, '\\t'),
        })),
        /**
         * Quoted escapes quoted values, such as database names.
         */
        quoted: bindEsc(new Escaper({
            '"': escaperConfig,
            '\\': escaperConfig,
        }, '"')),
        /**
         * TagEscaper escapes tag keys, tag values, and field keys.
         */
        tag: bindEsc(new Escaper({
            ',': escaperConfig,
            '=': escaperConfig,
            ' ': escaperConfig,
            '\n': new EscaperConfig(undefined, '\\n'),
            '\r': new EscaperConfig(undefined, '\\r'),
            '\t': new EscaperConfig(undefined, '\\t'),
        })),
    };

    var zeroPadding = '000000000';
    function useProcessHrtime(use) {
        /* istanbul ignore else */
        {
            return false;
        }
    }
    var lastMillis = Date.now();
    var stepsInMillis = 0;
    function nanos() {
        {
            var millis_2 = Date.now();
            if (millis_2 !== lastMillis) {
                lastMillis = millis_2;
                stepsInMillis = 0;
            }
            else {
                stepsInMillis++;
            }
            var nanos_2 = String(stepsInMillis);
            return String(millis_2) + zeroPadding.substr(0, 6 - nanos_2.length) + nanos_2;
        }
    }
    function micros() {
        {
            return String(Date.now()) + zeroPadding.substr(0, 3);
        }
    }
    function millis() {
        return String(Date.now());
    }
    function seconds() {
        return String(Math.floor(Date.now() / 1000));
    }
    /**
     * Exposes functions that creates strings that represent a timestamp that
     * can be used in the line protocol. Micro and nano timestamps are emulated
     * depending on the js platform in use.
     */
    var currentTime = Object.freeze({
        s: seconds,
        ms: millis,
        us: micros,
        ns: nanos,
        seconds: seconds,
        millis: millis,
        micros: micros,
        nanos: nanos,
    });
    /**
     * dateToProtocolTimestamp provides converters for JavaScript Date to InfluxDB Write Protocol Timestamp. Keys are supported precisions.
     */
    var dateToProtocolTimestamp = {
        s: function (d) { return "" + Math.floor(d.getTime() / 1000); },
        ms: function (d) { return "" + d.getTime(); },
        us: function (d) { return d.getTime() + "000"; },
        ns: function (d) { return d.getTime() + "000000"; },
    };

    var identity = function (x) { return x; };
    /**
     * A dictionary of serializers of particular types returned by a flux query.
     * See {@link https://v2.docs.influxdata.com/v2.0/reference/syntax/annotated-csv/#valid-data-types }
     */
    var typeSerializers = {
        boolean: function (x) { return x === 'true'; },
        unsignedLong: function (x) { return (x === '' ? null : +x); },
        long: function (x) { return (x === '' ? null : +x); },
        double: function (x) { return (x === '' ? null : +x); },
        string: identity,
        base64Binary: identity,
        duration: function (x) { return (x === '' ? null : x); },
        'dateTime:RFC3339': function (x) { return (x === '' ? null : x); },
    };
    /**
     * serializeDateTimeAsDate changes type serializers to return JavaScript Date instances
     * for 'dateTime:RFC3339' query result data type. Empty value is converted to null.
     * @remarks
     * Please note that the result has millisecond precision whereas InfluxDB returns dateTime
     * in nanosecond precision.
     */
    function serializeDateTimeAsDate() {
        typeSerializers['dateTime:RFC3339'] = function (x) {
            return x === '' ? null : new Date(Date.parse(x));
        };
    }
    /**
     * serializeDateTimeAsNumber changes type serializers to return milliseconds since epoch
     * for 'dateTime:RFC3339' query result data type. Empty value is converted to null.
     * @remarks
     * Please note that the result has millisecond precision whereas InfluxDB returns dateTime
     * in nanosecond precision.
     */
    function serializeDateTimeAsNumber() {
        typeSerializers['dateTime:RFC3339'] = function (x) {
            return x === '' ? null : Date.parse(x);
        };
    }
    /**
     * serializeDateTimeAsString changes type serializers to return string values
     * for `dateTime:RFC3339` query result data type.  Empty value is converted to null.
     */
    function serializeDateTimeAsString() {
        typeSerializers['dateTime:RFC3339'] = function (x) {
            return x === '' ? null : x;
        };
    }
    /**
     * FluxTableMetaData Implementation.
     */
    var FluxTableMetaDataImpl = /** @class */ (function () {
        function FluxTableMetaDataImpl(columns) {
            columns.forEach(function (col, i) { return (col.index = i); });
            this.columns = columns;
        }
        FluxTableMetaDataImpl.prototype.column = function (label) {
            for (var i = 0; i < this.columns.length; i++) {
                var col = this.columns[i];
                if (col.label === label)
                    return col;
            }
            throw new IllegalArgumentError("Column " + label + " not found!");
        };
        FluxTableMetaDataImpl.prototype.toObject = function (values) {
            var _a;
            var acc = {};
            for (var i = 0; i < this.columns.length && i < values.length; i++) {
                var val = values[i];
                var column = this.columns[i];
                if (val === '' && column.defaultValue) {
                    val = column.defaultValue;
                }
                acc[column.label] = ((_a = typeSerializers[column.dataType]) !== null && _a !== void 0 ? _a : identity)(val);
            }
            return acc;
        };
        return FluxTableMetaDataImpl;
    }());
    /**
     * Created FluxTableMetaData from the columns supplied.
     * @param columns -  columns
     * @returns - instance
     */
    function createFluxTableMetaData(columns) {
        return new FluxTableMetaDataImpl(columns);
    }

    /**
     * FluxTableColumn implementation.
     */
    var FluxTableColumnImpl = /** @class */ (function () {
        function FluxTableColumnImpl() {
        }
        return FluxTableColumnImpl;
    }());
    /**
     * Creates a new flux table column.
     * @returns column instance
     */
    function newFluxTableColumn() {
        return new FluxTableColumnImpl();
    }
    /**
     * Creates a flux table column from a partial FluxTableColumn.
     * @param object - source object
     * @returns column instance
     */
    function createFluxTableColumn(object) {
        var _a, _b;
        var retVal = new FluxTableColumnImpl();
        retVal.label = String(object.label);
        retVal.dataType = object.dataType;
        retVal.group = Boolean(object.group);
        retVal.defaultValue = (_a = object.defaultValue) !== null && _a !== void 0 ? _a : '';
        retVal.index = (_b = object.index) !== null && _b !== void 0 ? _b : 0;
        return retVal;
    }

    /** Property that offers a function that returns flux-sanitized value of an object.  */
    var FLUX_VALUE = Symbol('FLUX_VALUE');
    var FluxParameter = /** @class */ (function () {
        function FluxParameter(fluxValue) {
            this.fluxValue = fluxValue;
        }
        FluxParameter.prototype.toString = function () {
            return this.fluxValue;
        };
        FluxParameter.prototype[FLUX_VALUE] = function () {
            return this.fluxValue;
        };
        return FluxParameter;
    }());
    /**
     * Checks if the supplied object is FluxParameterLike
     * @param value - any value
     * @returns true if it is
     */
    function isFluxParameterLike(value) {
        return typeof value === 'object' && typeof value[FLUX_VALUE] === 'function';
    }
    /**
     * Escapes content of the supplied string so it can be wrapped into double qoutes
     * to become a [flux string literal](https://docs.influxdata.com/flux/v0.65/language/lexical-elements/#string-literals).
     * @param value - string value
     * @returns sanitized string
     */
    function sanitizeString(value) {
        if (value === null || value === undefined)
            return '';
        value = value.toString();
        var retVal = undefined;
        var i = 0;
        function prepareRetVal() {
            if (retVal === undefined) {
                retVal = value.substring(0, i);
            }
        }
        for (; i < value.length; i++) {
            var c = value.charAt(i);
            switch (c) {
                case '\r':
                    prepareRetVal();
                    retVal += '\\r';
                    break;
                case '\n':
                    prepareRetVal();
                    retVal += '\\n';
                    break;
                case '\t':
                    prepareRetVal();
                    retVal += '\\t';
                    break;
                case '"':
                case '\\':
                    prepareRetVal();
                    retVal = retVal + '\\' + c;
                    break;
                case '$':
                    // escape ${
                    if (i + 1 < value.length && value.charAt(i + 1) === '{') {
                        prepareRetVal();
                        i++;
                        retVal += '\\${';
                        break;
                    }
                    // append $
                    if (retVal != undefined) {
                        retVal += c;
                    }
                    break;
                default:
                    if (retVal != undefined) {
                        retVal += c;
                    }
            }
        }
        if (retVal !== undefined) {
            return retVal;
        }
        return value;
    }
    /**
     * Creates a flux string literal.
     */
    function fluxString(value) {
        return new FluxParameter("\"" + sanitizeString(value) + "\"");
    }
    /**
     * Creates a flux integer literal.
     */
    function fluxInteger(value) {
        var val = String(value);
        for (var _i = 0, val_1 = val; _i < val_1.length; _i++) {
            var c = val_1[_i];
            if (c < '0' || c > '9')
                throw new Error("not a flux integer: " + val);
        }
        return new FluxParameter(val);
    }
    /**
     * Sanitizes float value to avoid injections.
     * @param value - InfluxDB float literal
     * @returns sanitized float value
     * @throws Error if the the value cannot be sanitized
     */
    function sanitizeFloat(value) {
        var val = String(value);
        var dot = false;
        for (var _i = 0, val_2 = val; _i < val_2.length; _i++) {
            var c = val_2[_i];
            if (c === '.') {
                if (dot)
                    throw new Error("not a flux float: " + val);
                dot = !dot;
            }
            if (c !== '.' && (c < '0' || c > '9'))
                throw new Error("not a flux float: " + val);
        }
        return val;
    }
    /**
     * Creates a flux float literal.
     */
    function fluxFloat(value) {
        return new FluxParameter(sanitizeFloat(value));
    }
    function sanitizeDateTime(value) {
        return "time(v: \"" + sanitizeString(value) + "\")";
    }
    /**
     * Creates flux date-time literal.
     */
    function fluxDateTime(value) {
        return new FluxParameter(sanitizeDateTime(value));
    }
    /**
     * Creates flux date-time literal.
     */
    function fluxDuration(value) {
        return new FluxParameter("duration(v: \"" + sanitizeString(value) + "\")");
    }
    function sanitizeRegExp(value) {
        return "regexp.compile(v: \"" + sanitizeString(value) + "\")";
    }
    /**
     * Creates flux regexp literal.
     */
    function fluxRegExp(value) {
        // let the server decide if it can be parsed
        return new FluxParameter(sanitizeRegExp(value));
    }
    /**
     * Creates flux boolean literal.
     */
    function fluxBool(value) {
        if (value === 'true' || value === 'false') {
            return new FluxParameter(value);
        }
        return new FluxParameter((!!value).toString());
    }
    /**
     * Assumes that the supplied value is flux expression or literal that does not need sanitizing.
     *
     * @param value - any value
     * @returns the supplied value as-is
     */
    function fluxExpression(value) {
        return new FluxParameter(String(value));
    }
    /**
     * Escapes content of the supplied parameter so that it can be safely embedded into flux query.
     * @param value - parameter value
     * @returns sanitized flux value or an empty string if it cannot be converted
     */
    function toFluxValue(value) {
        if (value === undefined) {
            return '';
        }
        else if (value === null) {
            return 'null';
        }
        else if (typeof value === 'boolean') {
            return value.toString();
        }
        else if (typeof value === 'string') {
            return "\"" + sanitizeString(value) + "\"";
        }
        else if (typeof value === 'number') {
            return sanitizeFloat(value);
        }
        else if (typeof value === 'object') {
            if (typeof value[FLUX_VALUE] === 'function') {
                return value[FLUX_VALUE]();
            }
            else if (value instanceof Date) {
                return value.toISOString();
            }
            else if (value instanceof RegExp) {
                return sanitizeRegExp(value);
            }
            else if (Array.isArray(value)) {
                return "[" + value.map(toFluxValue).join(',') + "]";
            }
        }
        // use toString value for unrecognized object, bigint, symbol
        return toFluxValue(value.toString());
    }
    /**
     * Flux is a tagged template that sanitizes supplied parameters
     * to avoid injection attacks in flux.
     */
    function flux(strings) {
        var values = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            values[_i - 1] = arguments[_i];
        }
        if (strings.length == 1 && (!values || values.length === 0)) {
            return fluxExpression(strings[0]); // the simplest case
        }
        var parts = new Array(strings.length + values.length);
        var partIndex = 0;
        for (var i = 0; i < strings.length; i++) {
            var text = strings[i];
            parts[partIndex++] = text;
            if (i < values.length) {
                var val = values[i];
                var sanitized = void 0;
                if (text.endsWith('"') &&
                    i + 1 < strings.length &&
                    strings[i + 1].startsWith('"')) {
                    // parameter is wrapped into flux double quotes
                    sanitized = sanitizeString(val);
                }
                else {
                    sanitized = toFluxValue(val);
                    if (sanitized === '') {
                        // do not allow to insert empty strings, unless it is FluxParameterLike
                        if (!isFluxParameterLike(val)) {
                            throw new Error("Unsupported parameter literal '" + val + "' at index: " + i + ", type: " + typeof val);
                        }
                    }
                }
                parts[partIndex++] = sanitized;
            }
            else if (i < strings.length - 1) {
                throw new Error('Too few parameters supplied!');
            }
        }
        // return flux expression so that flux can be embedded into another flux as-is
        return fluxExpression(parts.join(''));
    }

    /* Observable interop typing. Taken from https://github.com/ReactiveX/rxjs */
    /** Symbol.observable or a string "\@\@observable". Used for interop */
    var symbolObservable = (function () {
        return (typeof Symbol === 'function' && Symbol.observable) || '@@observable';
    })();

    /**
     * Point defines values of a single measurement.
     */
    var Point = /** @class */ (function () {
        /**
         * Create a new Point with specified a measurement name.
         *
         * @param measurementName - the measurement name
         */
        function Point(measurementName) {
            this.tags = {};
            this.fields = {};
            if (measurementName)
                this.name = measurementName;
        }
        /**
         * Sets point's measurement.
         *
         * @param name - measurement name
         * @returns this
         */
        Point.prototype.measurement = function (name) {
            this.name = name;
            return this;
        };
        /**
         * Adds a tag.
         *
         * @param name - tag name
         * @param value - tag value
         * @returns this
         */
        Point.prototype.tag = function (name, value) {
            this.tags[name] = value;
            return this;
        };
        /**
         * Adds a boolean field.
         *
         * @param field - field name
         * @param value - field value
         * @returns this
         */
        Point.prototype.booleanField = function (name, value) {
            this.fields[name] = value ? 'T' : 'F';
            return this;
        };
        /**
         * Adds an integer field.
         *
         * @param name - field name
         * @param value - field value
         * @returns this
         */
        Point.prototype.intField = function (name, value) {
            if (typeof value !== 'number') {
                var val = void 0;
                if (isNaN((val = parseInt(String(value))))) {
                    throw new Error("Expected integer value for field " + name + ", but got '" + value + "'!");
                }
                value = val;
            }
            this.fields[name] = Math.floor(value) + "i";
            return this;
        };
        /**
         * Adds a number field.
         *
         * @param name - field name
         * @param value - field value
         * @returns this
         */
        Point.prototype.floatField = function (name, value) {
            if (typeof value !== 'number') {
                var val = void 0;
                if (isNaN((val = parseFloat(value)))) {
                    throw new Error("Expected float value for field " + name + ", but got '" + value + "'!");
                }
                value = val;
            }
            this.fields[name] = String(value);
            return this;
        };
        /**
         * Adds a string field.
         *
         * @param name - field name
         * @param value - field value
         * @returns this
         */
        Point.prototype.stringField = function (name, value) {
            if (value !== null && value !== undefined) {
                if (typeof value !== 'string')
                    value = String(value);
                this.fields[name] = escape.quoted(value);
            }
            return this;
        };
        /**
         * Sets point time. A string or number value can be used
         * to carry an int64 value of a precision that depends
         * on WriteApi, nanoseconds by default. An undefined value
         * generates a local timestamp using the client's clock.
         * An empty string can be used to let the server assign
         * the timestamp.
         *
         * @param value - point time
         * @returns this
         */
        Point.prototype.timestamp = function (value) {
            this.time = value;
            return this;
        };
        /**
         * Creates an InfluxDB protocol line out of this instance.
         * @param settings - settings define the exact representation of point time and can also add default tags
         * @returns an InfxluDB protocol line out of this instance
         */
        Point.prototype.toLineProtocol = function (settings) {
            var _this = this;
            if (!this.name)
                return undefined;
            var fieldsLine = '';
            Object.keys(this.fields)
                .sort()
                .forEach(function (x) {
                if (x) {
                    var val = _this.fields[x];
                    if (fieldsLine.length > 0)
                        fieldsLine += ',';
                    fieldsLine += escape.tag(x) + "=" + val;
                }
            });
            if (fieldsLine.length === 0)
                return undefined; // no fields present
            var tagsLine = '';
            var tags = settings && settings.defaultTags
                ? __assign(__assign({}, settings.defaultTags), this.tags) : this.tags;
            Object.keys(tags)
                .sort()
                .forEach(function (x) {
                if (x) {
                    var val = tags[x];
                    if (val) {
                        tagsLine += ',';
                        tagsLine += escape.tag(x) + "=" + escape.tag(val);
                    }
                }
            });
            var time = this.time;
            if (settings && settings.convertTime) {
                time = settings.convertTime(time);
            }
            return "" + escape.measurement(this.name) + tagsLine + " " + fieldsLine + (time !== undefined ? ' ' + time : '');
        };
        Point.prototype.toString = function () {
            var line = this.toLineProtocol(undefined);
            return line ? line : "invalid point: " + JSON.stringify(this, undefined);
        };
        return Point;
    }());

    /**
     * Logger that logs to console.out
     */
    var consoleLogger = Object.freeze({
        error: function (message, error) {
            // eslint-disable-next-line no-console
            console.error('ERROR: ' + message, error ? error : '');
        },
        warn: function (message, error) {
            // eslint-disable-next-line no-console
            console.warn('WARN: ' + message, error ? error : '');
        },
    });
    var provider = consoleLogger;
    var Logger = {
        error: function (message, error) {
            provider.error(message, error);
        },
        warn: function (message, error) {
            provider.warn(message, error);
        },
    };

    /**
     * Applies a variant of exponential backoff with initial and max delay and a random
     * jitter delay. It also respects `retry delay` when specified together with an error.
     */
    var RetryStrategyImpl = /** @class */ (function () {
        function RetryStrategyImpl(options) {
            this.options = __assign(__assign({}, DEFAULT_RetryDelayStrategyOptions), options);
            this.success();
        }
        RetryStrategyImpl.prototype.nextDelay = function (error, failedAttempts) {
            var delay = getRetryDelay(error);
            if (delay && delay > 0) {
                return delay + Math.round(Math.random() * this.options.retryJitter);
            }
            else {
                var delay_1 = this.currentDelay;
                if (failedAttempts && failedAttempts > 0) {
                    // compute delay
                    delay_1 = this.options.minRetryDelay;
                    for (var i = 1; i < failedAttempts; i++) {
                        delay_1 = delay_1 * this.options.exponentialBase;
                        if (delay_1 >= this.options.maxRetryDelay) {
                            break;
                        }
                    }
                    return (Math.min(Math.max(delay_1, 1), this.options.maxRetryDelay) +
                        Math.round(Math.random() * this.options.retryJitter));
                }
                else if (this.currentDelay) {
                    this.currentDelay = Math.min(Math.max(this.currentDelay * this.options.exponentialBase, 1) +
                        Math.round(Math.random() * this.options.retryJitter), this.options.maxRetryDelay);
                }
                else {
                    this.currentDelay =
                        this.options.minRetryDelay +
                            Math.round(Math.random() * this.options.retryJitter);
                }
                return this.currentDelay;
            }
        };
        RetryStrategyImpl.prototype.success = function () {
            this.currentDelay = undefined;
        };
        return RetryStrategyImpl;
    }());
    /**
     * Creates a new instance of retry strategy.
     * @param options - retry options
     * @returns retry strategy implementation
     */
    function createRetryDelayStrategy(options) {
        return new RetryStrategyImpl(options);
    }

    /* interval between successful retries */
    var RETRY_INTERVAL = 1;
    /**
     * Retries lines up to a limit of max buffer size.
     */
    var RetryBuffer = /** @class */ (function () {
        function RetryBuffer(maxLines, retryLines) {
            this.maxLines = maxLines;
            this.retryLines = retryLines;
            this.size = 0;
            this.nextRetryTime = 0;
            this.closed = false;
            this._timeoutHandle = undefined;
        }
        RetryBuffer.prototype.addLines = function (lines, retryCount, delay) {
            if (this.closed)
                return;
            if (!lines.length)
                return;
            var retryTime = Date.now() + delay;
            if (retryTime > this.nextRetryTime)
                this.nextRetryTime = retryTime;
            // ensure at most maxLines are in the Buffer
            if (this.first && this.size + lines.length > this.maxLines) {
                var origSize = this.size;
                var newSize = origSize * 0.7; // reduce to 70 %
                do {
                    var newFirst = this.first.next;
                    this.size -= this.first.lines.length;
                    this.first = newFirst;
                } while (this.first && this.size + lines.length > newSize);
                Logger.error("RetryBuffer: " + (origSize -
                    this
                        .size) + " oldest lines removed to keep buffer size under the limit of " + this.maxLines + " lines");
            }
            var toAdd = {
                lines: lines,
                retryCount: retryCount,
            };
            if (this.last) {
                this.last.next = toAdd;
                this.last = toAdd;
            }
            else {
                this.first = toAdd;
                this.last = toAdd;
                this.scheduleRetry(delay);
            }
            this.size += lines.length;
        };
        RetryBuffer.prototype.removeLines = function () {
            if (this.first) {
                var toRetry = this.first;
                this.first = this.first.next;
                this.size -= toRetry.lines.length;
                if (!this.first)
                    this.last = undefined;
                return toRetry;
            }
            return undefined;
        };
        RetryBuffer.prototype.scheduleRetry = function (delay) {
            var _this = this;
            this._timeoutHandle = setTimeout(function () {
                var toRetry = _this.removeLines();
                if (toRetry) {
                    _this.retryLines(toRetry.lines, toRetry.retryCount)
                        .then(function () {
                        // continue with successfull retry
                        _this.scheduleRetry(RETRY_INTERVAL);
                    })
                        .catch(function (_e) {
                        // already logged
                        _this.scheduleRetry(_this.nextRetryTime - Date.now());
                    });
                }
                else {
                    _this._timeoutHandle = undefined;
                }
            }, delay);
        };
        RetryBuffer.prototype.flush = function () {
            return __awaiter(this, void 0, void 0, function () {
                var toRetry;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            if (!(toRetry = this.removeLines())) return [3 /*break*/, 2];
                            return [4 /*yield*/, this.retryLines(toRetry.lines, toRetry.retryCount)];
                        case 1:
                            _a.sent();
                            return [3 /*break*/, 0];
                        case 2: return [2 /*return*/];
                    }
                });
            });
        };
        RetryBuffer.prototype.close = function () {
            if (this._timeoutHandle) {
                clearTimeout(this._timeoutHandle);
                this._timeoutHandle = undefined;
            }
            this.closed = true;
            return this.size;
        };
        return RetryBuffer;
    }());

    var WriteBuffer = /** @class */ (function () {
        function WriteBuffer(maxChunkRecords, flushFn, scheduleSend) {
            this.maxChunkRecords = maxChunkRecords;
            this.flushFn = flushFn;
            this.scheduleSend = scheduleSend;
            this.length = 0;
            this.lines = new Array(maxChunkRecords);
        }
        WriteBuffer.prototype.add = function (record) {
            if (this.length === 0) {
                this.scheduleSend();
            }
            this.lines[this.length] = record;
            this.length++;
            if (this.length >= this.maxChunkRecords) {
                this.flush().catch(function (_e) {
                    // an error is logged in case of failure, avoid UnhandledPromiseRejectionWarning
                });
            }
        };
        WriteBuffer.prototype.flush = function () {
            var lines = this.reset();
            if (lines.length > 0) {
                return this.flushFn(lines);
            }
            else {
                return Promise.resolve();
            }
        };
        WriteBuffer.prototype.reset = function () {
            var retVal = this.lines.slice(0, this.length);
            this.length = 0;
            return retVal;
        };
        return WriteBuffer;
    }());
    var WriteApiImpl = /** @class */ (function () {
        function WriteApiImpl(transport, org, bucket, precision, writeOptions) {
            var _this = this;
            this.transport = transport;
            this.closed = false;
            this.sendOptions = {
                method: 'POST',
                headers: {
                    'content-type': 'text/plain; charset=utf-8',
                },
            };
            this._timeoutHandle = undefined;
            this.httpPath = "/api/v2/write?org=" + encodeURIComponent(org) + "&bucket=" + encodeURIComponent(bucket) + "&precision=" + precision;
            this.writeOptions = __assign(__assign({}, DEFAULT_WriteOptions), writeOptions);
            this.currentTime = currentTime[precision];
            this.dateToProtocolTimestamp = dateToProtocolTimestamp[precision];
            if (this.writeOptions.defaultTags) {
                this.useDefaultTags(this.writeOptions.defaultTags);
            }
            var scheduleNextSend = function () {
                if (_this.writeOptions.flushInterval > 0) {
                    _this._clearFlushTimeout();
                    /* istanbul ignore else manually reviewed, hard to reproduce */
                    if (!_this.closed) {
                        _this._timeoutHandle = setTimeout(function () {
                            return _this.sendBatch(_this.writeBuffer.reset(), _this.writeOptions.maxRetries + 1).catch(function (_e) {
                                // an error is logged in case of failure, avoid UnhandledPromiseRejectionWarning
                            });
                        }, _this.writeOptions.flushInterval);
                    }
                }
            };
            // write buffer
            this.writeBuffer = new WriteBuffer(this.writeOptions.batchSize, function (lines) {
                _this._clearFlushTimeout();
                return _this.sendBatch(lines, _this.writeOptions.maxRetries + 1);
            }, scheduleNextSend);
            this.sendBatch = this.sendBatch.bind(this);
            // retry buffer
            this.retryStrategy = createRetryDelayStrategy(this.writeOptions);
            this.retryBuffer = new RetryBuffer(this.writeOptions.maxBufferLines, this.sendBatch);
        }
        WriteApiImpl.prototype.sendBatch = function (lines, attempts) {
            var _this = this;
            // eslint-disable-next-line @typescript-eslint/no-this-alias
            var self = this;
            if (!this.closed && lines.length > 0) {
                return new Promise(function (resolve, reject) {
                    _this.transport.send(_this.httpPath, lines.join('\n'), _this.sendOptions, {
                        error: function (error) {
                            var failedAttempts = self.writeOptions.maxRetries + 2 - attempts;
                            // call the writeFailed listener and check if we can retry
                            var onRetry = self.writeOptions.writeFailed.call(self, error, lines, failedAttempts);
                            if (onRetry) {
                                onRetry.then(resolve, reject);
                                return;
                            }
                            if (!self.closed &&
                                attempts > 1 &&
                                (!(error instanceof HttpError) ||
                                    error.statusCode >= 429)) {
                                Logger.warn("Write to InfluxDB failed (remaining attempts: " + (attempts -
                                    1) + ").", error);
                                self.retryBuffer.addLines(lines, attempts - 1, self.retryStrategy.nextDelay(error, failedAttempts));
                                reject(error);
                                return;
                            }
                            Logger.error("Write to InfluxDB failed.", error);
                            reject(error);
                        },
                        complete: function () {
                            self.retryStrategy.success();
                            resolve();
                        },
                    });
                });
            }
            else {
                return Promise.resolve();
            }
        };
        WriteApiImpl.prototype._clearFlushTimeout = function () {
            if (this._timeoutHandle !== undefined) {
                clearTimeout(this._timeoutHandle);
                this._timeoutHandle = undefined;
            }
        };
        WriteApiImpl.prototype.writeRecord = function (record) {
            if (this.closed) {
                throw new Error('writeApi: already closed!');
            }
            this.writeBuffer.add(record);
        };
        WriteApiImpl.prototype.writeRecords = function (records) {
            if (this.closed) {
                throw new Error('writeApi: already closed!');
            }
            for (var i = 0; i < records.length; i++) {
                this.writeBuffer.add(records[i]);
            }
        };
        WriteApiImpl.prototype.writePoint = function (point) {
            if (this.closed) {
                throw new Error('writeApi: already closed!');
            }
            var line = point.toLineProtocol(this);
            if (line)
                this.writeBuffer.add(line);
        };
        WriteApiImpl.prototype.writePoints = function (points) {
            if (this.closed) {
                throw new Error('writeApi: already closed!');
            }
            for (var i = 0; i < points.length; i++) {
                this.writePoint(points[i]);
            }
        };
        WriteApiImpl.prototype.flush = function (withRetryBuffer) {
            return __awaiter(this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.writeBuffer.flush()];
                        case 1:
                            _a.sent();
                            if (!withRetryBuffer) return [3 /*break*/, 3];
                            return [4 /*yield*/, this.retryBuffer.flush()];
                        case 2: return [2 /*return*/, _a.sent()];
                        case 3: return [2 /*return*/];
                    }
                });
            });
        };
        WriteApiImpl.prototype.close = function () {
            var _this = this;
            var retVal = this.writeBuffer.flush().finally(function () {
                var remaining = _this.retryBuffer.close();
                if (remaining) {
                    Logger.error("Retry buffer closed with " + remaining + " items that were not written to InfluxDB!", null);
                }
                _this.closed = true;
            });
            return retVal;
        };
        WriteApiImpl.prototype.dispose = function () {
            this._clearFlushTimeout();
            this.closed = true;
            return this.retryBuffer.close() + this.writeBuffer.length;
        };
        WriteApiImpl.prototype.useDefaultTags = function (tags) {
            var _this = this;
            this.defaultTags = undefined;
            Object.keys(tags).forEach(function (key) {
                (_this.defaultTags || (_this.defaultTags = {}))[key] = escape.tag(tags[key]);
            });
            return this;
        };
        WriteApiImpl.prototype.convertTime = function (value) {
            if (value === undefined) {
                return this.currentTime();
            }
            else if (typeof value === 'string') {
                return value.length > 0 ? value : undefined;
            }
            else if (value instanceof Date) {
                return this.dateToProtocolTimestamp(value);
            }
            else if (typeof value === 'number') {
                return String(Math.floor(value));
            }
            else {
                // Logger.warn(`unsupported timestamp value: ${value}`)
                return String(value);
            }
        };
        return WriteApiImpl;
    }());

    var pureJsChunkCombiner = {
        concat: function (first, second) {
            var retVal = new Uint8Array(first.length + second.length);
            retVal.set(first);
            retVal.set(second, first.length);
            return retVal;
        },
        toUtf8String: function (chunk, start, end) {
            // see https://en.wikipedia.org/wiki/UTF-8 for details
            var c1, c2, c3, c4;
            var out = '';
            var i = start;
            while (i < end) {
                c1 = chunk[i++];
                switch (c1 >> 4) {
                    case 0:
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                        // 0xxxxxxx
                        out += String.fromCharCode(c1);
                        break;
                    case 12:
                    case 13:
                        // 110x xxxx   10xx xxxx
                        c2 = chunk[i++];
                        out += String.fromCharCode(((c1 & 0x1f) << 6) | (c2 & 0x3f));
                        break;
                    case 14:
                        // 1110 xxxx  10xx xxxx  10xx xxxx
                        c2 = chunk[i++];
                        c3 = chunk[i++];
                        out += String.fromCharCode(((c1 & 0x0f) << 12) | ((c2 & 0x3f) << 6) | (c3 & 0x3f));
                        break;
                    case 15:
                        // 1111 0xxx  10xx xxxx  10xx xxxx 10xx xxxx
                        c2 = chunk[i++];
                        c3 = chunk[i++];
                        c4 = chunk[i++];
                        out += String.fromCodePoint(((c1 & 0x07) << 18) |
                            ((c2 & 0x3f) << 12) |
                            ((c3 & 0x3f) << 6) |
                            (c4 & 0x3f));
                        break;
                }
            }
            return out;
        },
        copy: function (chunk, start, end) {
            var retVal = new Uint8Array(end - start);
            retVal.set(chunk.slice(start, end));
            return retVal;
        },
    };

    function completeCommunicationObserver(callbacks) {
        if (callbacks === void 0) { callbacks = {}; }
        var state = 0;
        var retVal = {
            next: function (data) {
                if (state === 0 &&
                    callbacks.next &&
                    data !== null &&
                    data !== undefined) {
                    callbacks.next(data);
                }
            },
            error: function (error) {
                /* istanbul ignore else propagate error at most once */
                if (state === 0) {
                    state = 1;
                    /* istanbul ignore else safety check */
                    if (callbacks.error)
                        callbacks.error(error);
                }
            },
            complete: function () {
                if (state === 0) {
                    state = 2;
                    /* istanbul ignore else safety check */
                    if (callbacks.complete)
                        callbacks.complete();
                }
            },
            responseStarted: function (headers) {
                if (callbacks.responseStarted)
                    callbacks.responseStarted(headers);
            },
        };
        return retVal;
    }

    var CLIENT_LIB_VERSION = '1.7.1';

    /**
     * Transport layer that use browser fetch.
     */
    var FetchTransport = /** @class */ (function () {
        function FetchTransport(connectionOptions) {
            this.connectionOptions = connectionOptions;
            this.chunkCombiner = pureJsChunkCombiner;
            this.defaultHeaders = {
                'content-type': 'application/json; charset=utf-8',
                'User-Agent': "influxdb-client-js/" + CLIENT_LIB_VERSION,
            };
            if (this.connectionOptions.token) {
                this.defaultHeaders['Authorization'] =
                    'Token ' + this.connectionOptions.token;
            }
        }
        FetchTransport.prototype.send = function (path, body, options, callbacks) {
            var _this = this;
            var observer = completeCommunicationObserver(callbacks);
            var cancelled = false;
            var signal = options.signal;
            if (callbacks && callbacks.useCancellable) {
                var controller_1 = new AbortController();
                if (!signal) {
                    signal = controller_1.signal;
                    options = __assign(__assign({}, options), signal);
                }
                callbacks.useCancellable({
                    cancel: function () {
                        cancelled = true;
                        controller_1.abort();
                    },
                    isCancelled: function () {
                        return cancelled || signal.aborted;
                    },
                });
            }
            this.fetch(path, body, options)
                .then(function (response) { return __awaiter(_this, void 0, void 0, function () {
                var headers_1, reader, chunk, buffer, text;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            if (callbacks === null || callbacks === void 0 ? void 0 : callbacks.responseStarted) {
                                headers_1 = {};
                                response.headers.forEach(function (value, key) {
                                    var previous = headers_1[key];
                                    if (previous === undefined) {
                                        headers_1[key] = value;
                                    }
                                    else if (Array.isArray(previous)) {
                                        previous.push(value);
                                    }
                                    else {
                                        headers_1[key] = [previous, value];
                                    }
                                });
                                observer.responseStarted(headers_1);
                            }
                            if (!(response.status >= 300)) return [3 /*break*/, 1];
                            return [2 /*return*/, response
                                    .text()
                                    .then(function (text) {
                                    if (!text) {
                                        var headerError = response.headers.get('x-influxdb-error');
                                        if (headerError) {
                                            text = headerError;
                                        }
                                    }
                                    observer.error(new HttpError(response.status, response.statusText, text, response.headers.get('retry-after')));
                                })
                                    .catch(function (e) {
                                    Logger.warn('Unable to receive error body', e);
                                    observer.error(new HttpError(response.status, response.statusText, undefined, response.headers.get('retry-after')));
                                })];
                        case 1:
                            if (!response.body) return [3 /*break*/, 6];
                            reader = response.body.getReader();
                            chunk = void 0;
                            _a.label = 2;
                        case 2: return [4 /*yield*/, reader.read()];
                        case 3:
                            chunk = _a.sent();
                            observer.next(chunk.value);
                            _a.label = 4;
                        case 4:
                            if (!chunk.done) return [3 /*break*/, 2];
                            _a.label = 5;
                        case 5: return [3 /*break*/, 10];
                        case 6:
                            if (!response.arrayBuffer) return [3 /*break*/, 8];
                            return [4 /*yield*/, response.arrayBuffer()];
                        case 7:
                            buffer = _a.sent();
                            observer.next(new Uint8Array(buffer));
                            return [3 /*break*/, 10];
                        case 8: return [4 /*yield*/, response.text()];
                        case 9:
                            text = _a.sent();
                            observer.next(new TextEncoder().encode(text));
                            _a.label = 10;
                        case 10: return [2 /*return*/];
                    }
                });
            }); })
                .catch(function (e) {
                if (!cancelled) {
                    observer.error(e);
                }
            })
                .finally(function () { return observer.complete(); });
        };
        FetchTransport.prototype.request = function (path, body, options) {
            var _a, _b;
            return __awaiter(this, void 0, void 0, function () {
                var response, status, headers, responseContentType, data, headerError, responseType;
                return __generator(this, function (_c) {
                    switch (_c.label) {
                        case 0: return [4 /*yield*/, this.fetch(path, body, options)];
                        case 1:
                            response = _c.sent();
                            status = response.status, headers = response.headers;
                            responseContentType = headers.get('content-type') || '';
                            if (!(status >= 300)) return [3 /*break*/, 3];
                            return [4 /*yield*/, response.text()];
                        case 2:
                            data = _c.sent();
                            if (!data) {
                                headerError = headers.get('x-influxdb-error');
                                if (headerError) {
                                    data = headerError;
                                }
                            }
                            throw new HttpError(status, response.statusText, data, response.headers.get('retry-after'));
                        case 3:
                            responseType = (_b = (_a = options.headers) === null || _a === void 0 ? void 0 : _a.accept) !== null && _b !== void 0 ? _b : responseContentType;
                            if (!responseType.includes('json')) return [3 /*break*/, 5];
                            return [4 /*yield*/, response.json()];
                        case 4: return [2 /*return*/, _c.sent()];
                        case 5:
                            if (!(responseType.includes('text') ||
                                responseType.startsWith('application/csv'))) return [3 /*break*/, 7];
                            return [4 /*yield*/, response.text()];
                        case 6: return [2 /*return*/, _c.sent()];
                        case 7: return [2 /*return*/];
                    }
                });
            });
        };
        FetchTransport.prototype.fetch = function (path, body, options) {
            var method = options.method, headers = options.headers, other = __rest(options, ["method", "headers"]);
            return fetch("" + this.connectionOptions.url + path, __assign({ method: method, body: method === 'GET' || method === 'HEAD'
                    ? undefined
                    : typeof body === 'string'
                        ? body
                        : JSON.stringify(body), headers: __assign(__assign({}, this.defaultHeaders), headers), credentials: 'omit' }, other));
        };
        return FetchTransport;
    }());

    function defaultRowMapping(values, tableMeta) {
        return tableMeta.toObject(values);
    }

    /**
     * Converts lines to table calls
     */
    var ChunksToLines = /** @class */ (function () {
        function ChunksToLines(target, chunks) {
            this.target = target;
            this.chunks = chunks;
            this.finished = false;
            this.quoted = false;
        }
        ChunksToLines.prototype.next = function (chunk) {
            if (this.finished)
                return;
            try {
                this.bufferReceived(chunk);
            }
            catch (e) {
                this.error(e);
            }
        };
        ChunksToLines.prototype.error = function (error) {
            if (!this.finished) {
                this.finished = true;
                this.target.error(error);
            }
        };
        ChunksToLines.prototype.complete = function () {
            if (!this.finished) {
                if (this.previous) {
                    this.target.next(this.chunks.toUtf8String(this.previous, 0, this.previous.length));
                }
                this.finished = true;
                this.target.complete();
            }
        };
        ChunksToLines.prototype.useCancellable = function (cancellable) {
            if (this.target.useCancellable) {
                // eslint-disable-next-line @typescript-eslint/no-this-alias
                var self_1 = this;
                this.target.useCancellable({
                    cancel: function () {
                        cancellable.cancel();
                        self_1.previous = undefined; // do not emit more lines
                        self_1.complete();
                    },
                    isCancelled: function () {
                        return cancellable.isCancelled();
                    },
                });
            }
        };
        ChunksToLines.prototype.bufferReceived = function (chunk) {
            var index;
            var start = 0;
            if (this.previous) {
                chunk = this.chunks.concat(this.previous, chunk);
                index = this.previous.length;
            }
            else {
                index = 0;
            }
            while (index < chunk.length) {
                var c = chunk[index];
                if (c === 10) {
                    if (!this.quoted) {
                        /* do not emit CR+LR or LF line ending */
                        var end = index > 0 && chunk[index - 1] === 13 ? index - 1 : index;
                        // do not emmit more lines if the processing is already finished
                        if (this.finished) {
                            return;
                        }
                        this.target.next(this.chunks.toUtf8String(chunk, start, end));
                        start = index + 1;
                    }
                }
                else if (c === 34 /* " */) {
                    this.quoted = !this.quoted;
                }
                index++;
            }
            if (start < index) {
                this.previous = this.chunks.copy(chunk, start, index);
            }
            else {
                this.previous = undefined;
            }
        };
        return ChunksToLines;
    }());

    var SEPARATOR = ',';
    var WRAPPER = '"';
    /**
     * Optimized tokenizer of a single CSV line.
     */
    var LineSplitter = /** @class */ (function () {
        function LineSplitter() {
            this._reuse = false;
        }
        Object.defineProperty(LineSplitter.prototype, "reuse", {
            /**
             * Reuse returned array between consecutive calls.
             */
            get: function () {
                return this._reuse;
            },
            set: function (val) {
                if (val && !this.reusedValues) {
                    this.reusedValues = new Array(10);
                }
                this._reuse = val;
            },
            enumerable: false,
            configurable: true
        });
        /**
         * Sets the reuse flag and returns this.
         */
        LineSplitter.prototype.withReuse = function () {
            this.reuse = true;
            return this;
        };
        /**
         * Splits the supplied line to elements that are separated by
         * comma with values possibly escaped within double quotes ("value")
         * @param line - line
         * @returns array of splitted parts
         */
        LineSplitter.prototype.splitLine = function (line) {
            if (line === null || line === undefined) {
                this.lastSplitLength = 0;
                return [];
            }
            var quoteCount = 0;
            var startIndex = 0;
            var values = this._reuse ? this.reusedValues : [];
            var count = 0;
            for (var i = 0; i < line.length; i++) {
                var c = line[i];
                if (c === SEPARATOR) {
                    if (quoteCount % 2 === 0) {
                        var val_1 = this.getValue(line, startIndex, i, quoteCount);
                        if (this._reuse) {
                            values[count++] = val_1;
                        }
                        else {
                            values.push(val_1);
                        }
                        startIndex = i + 1;
                        quoteCount = 0;
                    }
                }
                else if (c === WRAPPER) {
                    quoteCount++;
                }
            }
            var val = this.getValue(line, startIndex, line.length, quoteCount);
            if (this._reuse) {
                values[count] = val;
                this.lastSplitLength = count + 1;
            }
            else {
                values.push(val);
                this.lastSplitLength = values.length;
            }
            return values;
        };
        LineSplitter.prototype.getValue = function (line, start, end, quoteCount) {
            if (start === line.length) {
                return '';
            }
            else if (quoteCount === 0) {
                return line.substring(start, end);
            }
            else if (quoteCount === 2) {
                return line.substring(start + 1, end - 1);
            }
            else {
                // quoteCount >= 4
                return line.substring(start + 1, end - 1).replace(/""/gi, '"');
            }
        };
        return LineSplitter;
    }());

    function toLineObserver(consumer) {
        var splitter = new LineSplitter().withReuse();
        var columns;
        var expectMeta = true;
        var firstColumnIndex = 0;
        var lastMeta;
        return {
            error: function (error) {
                consumer.error(error);
            },
            next: function (line) {
                if (line === '') {
                    expectMeta = true;
                    columns = undefined;
                }
                else {
                    var values = splitter.splitLine(line);
                    var size = splitter.lastSplitLength;
                    if (expectMeta) {
                        // create columns
                        if (!columns) {
                            columns = new Array(size);
                            for (var i = 0; i < size; i++) {
                                columns[i] = newFluxTableColumn();
                            }
                        }
                        if (!values[0].startsWith('#')) {
                            // fill in column names
                            if (values[0] === '') {
                                firstColumnIndex = 1;
                                columns = columns.slice(1);
                            }
                            else {
                                firstColumnIndex = 0;
                            }
                            for (var i = firstColumnIndex; i < size; i++) {
                                columns[i - firstColumnIndex].label = values[i];
                            }
                            lastMeta = createFluxTableMetaData(columns);
                            expectMeta = false;
                        }
                        else if (values[0] === '#datatype') {
                            for (var i = 1; i < size; i++) {
                                columns[i].dataType = values[i];
                            }
                        }
                        else if (values[0] === '#default') {
                            for (var i = 1; i < size; i++) {
                                columns[i].defaultValue = values[i];
                            }
                        }
                        else if (values[0] === '#group') {
                            for (var i = 1; i < size; i++) {
                                columns[i].group = values[i][0] === 't';
                            }
                        }
                    }
                    else {
                        consumer.next(values.slice(firstColumnIndex, size), lastMeta);
                    }
                }
            },
            complete: function () {
                consumer.complete();
            },
            useCancellable: function (cancellable) {
                if (consumer.useCancellable)
                    consumer.useCancellable(cancellable);
            },
        };
    }

    var QuerySubscription = /** @class */ (function () {
        function QuerySubscription(observer, executor) {
            var _this = this;
            this.isClosed = false;
            try {
                executor({
                    next: function (value) {
                        observer.next(value);
                    },
                    error: function (e) {
                        _this.isClosed = true;
                        observer.error(e);
                    },
                    complete: function () {
                        _this.isClosed = true;
                        observer.complete();
                    },
                    useCancellable: function (c) {
                        _this.cancellable = c;
                    },
                });
            }
            catch (e) {
                this.isClosed = true;
                observer.error(e);
            }
        }
        Object.defineProperty(QuerySubscription.prototype, "closed", {
            get: function () {
                return this.isClosed;
            },
            enumerable: false,
            configurable: true
        });
        QuerySubscription.prototype.unsubscribe = function () {
            var _a;
            (_a = this.cancellable) === null || _a === void 0 ? void 0 : _a.cancel();
            this.isClosed = true;
        };
        return QuerySubscription;
    }());
    function noop() { }
    function completeObserver(observer) {
        var next = observer.next, error = observer.error, complete = observer.complete;
        return {
            next: next ? next.bind(observer) : noop,
            error: error ? error.bind(observer) : noop,
            complete: complete ? complete.bind(observer) : noop,
        };
    }
    var ObservableQuery = /** @class */ (function () {
        function ObservableQuery(executor, decorator) {
            this.executor = executor;
            this.decorator = decorator;
        }
        ObservableQuery.prototype.subscribe = function (observerOrNext, error, complete) {
            var observer = completeObserver(typeof observerOrNext !== 'object' || observerOrNext === null
                ? { next: observerOrNext, error: error, complete: complete }
                : observerOrNext);
            return new QuerySubscription(this.decorator(observer), this.executor);
        };
        ObservableQuery.prototype[symbolObservable] = function () {
            return this;
        };
        return ObservableQuery;
    }());

    var DEFAULT_dialect = {
        header: true,
        delimiter: ',',
        quoteChar: '"',
        commentPrefix: '#',
        annotations: ['datatype', 'group', 'default'],
    };
    var identity$1 = function (value) { return value; };
    var QueryApiImpl = /** @class */ (function () {
        function QueryApiImpl(transport, org) {
            this.transport = transport;
            this.options = { org: org };
        }
        QueryApiImpl.prototype.with = function (options) {
            this.options = __assign(__assign({}, this.options), options);
            return this;
        };
        QueryApiImpl.prototype.lines = function (query) {
            return new ObservableQuery(this.createExecutor(query), identity$1);
        };
        QueryApiImpl.prototype.rows = function (query) {
            return new ObservableQuery(this.createExecutor(query), function (observer) {
                return toLineObserver({
                    next: function (values, tableMeta) {
                        observer.next({ values: values, tableMeta: tableMeta });
                    },
                    error: function (e) {
                        observer.error(e);
                    },
                    complete: function () {
                        observer.complete();
                    },
                });
            });
        };
        QueryApiImpl.prototype.queryLines = function (query, consumer) {
            this.createExecutor(query)(consumer);
        };
        QueryApiImpl.prototype.queryRows = function (query, consumer) {
            this.createExecutor(query)(toLineObserver(consumer));
        };
        QueryApiImpl.prototype.collectRows = function (query, rowMapper) {
            var _this = this;
            if (rowMapper === void 0) { rowMapper = defaultRowMapping; }
            var retVal = [];
            return new Promise(function (resolve, reject) {
                _this.queryRows(query, {
                    next: function (values, tableMeta) {
                        var toAdd = rowMapper.call(this, values, tableMeta);
                        if (toAdd !== undefined) {
                            retVal.push(toAdd);
                        }
                    },
                    error: function (error) {
                        reject(error);
                    },
                    complete: function () {
                        resolve(retVal);
                    },
                });
            });
        };
        QueryApiImpl.prototype.collectLines = function (query) {
            var _this = this;
            var retVal = [];
            return new Promise(function (resolve, reject) {
                _this.queryLines(query, {
                    next: function (line) {
                        retVal.push(line);
                    },
                    error: function (error) {
                        reject(error);
                    },
                    complete: function () {
                        resolve(retVal);
                    },
                });
            });
        };
        QueryApiImpl.prototype.queryRaw = function (query) {
            var _a = this.options, org = _a.org, type = _a.type, gzip = _a.gzip;
            return this.transport.request("/api/v2/query?org=" + encodeURIComponent(org), JSON.stringify(this.decorateRequest({
                query: query.toString(),
                dialect: DEFAULT_dialect,
                type: type,
            })), {
                method: 'POST',
                headers: {
                    accept: 'text/csv',
                    'accept-encoding': gzip ? 'gzip' : 'identity',
                    'content-type': 'application/json; encoding=utf-8',
                },
            });
        };
        QueryApiImpl.prototype.createExecutor = function (query) {
            var _this = this;
            var _a = this.options, org = _a.org, type = _a.type, gzip = _a.gzip;
            return function (consumer) {
                _this.transport.send("/api/v2/query?org=" + encodeURIComponent(org), JSON.stringify(_this.decorateRequest({
                    query: query.toString(),
                    dialect: DEFAULT_dialect,
                    type: type,
                })), {
                    method: 'POST',
                    headers: {
                        'content-type': 'application/json; encoding=utf-8',
                        'accept-encoding': gzip ? 'gzip' : 'identity',
                    },
                }, new ChunksToLines(consumer, _this.transport.chunkCombiner));
            };
        };
        QueryApiImpl.prototype.decorateRequest = function (request) {
            var _a;
            if (typeof this.options.now === 'function') {
                request.now = this.options.now();
            }
            // https://v2.docs.influxdata.com/v2.0/api/#operation/PostQuery requires type
            request.type = (_a = this.options.type) !== null && _a !== void 0 ? _a : 'flux';
            return request;
        };
        return QueryApiImpl;
    }());

    /**
     * InfluxDB 2.0 entry point that configures communication with InfluxDB server
     * and provide APIs to write and query data.
     */
    var InfluxDB = /** @class */ (function () {
        /**
         * Creates influxdb client options from an options object or url.
         * @param options - client options
         */
        function InfluxDB(options) {
            var _a;
            if (typeof options === 'string') {
                this._options = { url: options };
            }
            else if (options !== null && typeof options === 'object') {
                this._options = options;
            }
            else {
                throw new IllegalArgumentError('No url or configuration specified!');
            }
            var url = this._options.url;
            if (typeof url !== 'string')
                throw new IllegalArgumentError('No url specified!');
            if (url.endsWith('/'))
                this._options.url = url.substring(0, url.length - 1);
            this.transport = (_a = this._options.transport) !== null && _a !== void 0 ? _a : new FetchTransport(this._options);
        }
        /**
         * Creates WriteApi for the supplied organization and bucket. BEWARE that returned instances must be closed
         * in order to flush the remaining data and close already scheduled retry executions.
         *
         * @remarks
         * Inspect the {@link WriteOptions} to control also advanced options, such retries of failure, retry strategy options, data chunking
         * and flushing windows. See {@link DEFAULT_WriteOptions} to see the defaults.
         *
         * See also {@link https://github.com/influxdata/influxdb-client-js/blob/master/examples/write.js | write.js example},
         * {@link https://github.com/influxdata/influxdb-client-js/blob/master/examples/writeAdvanced.js | writeAdvanced.js example},
         * and {@link https://github.com/influxdata/influxdb-client-js/blob/master/examples/index.html | browser example}.
         *
         * @param org - Specifies the destination organization for writes. Takes either the ID or Name interchangeably.
         * @param bucket - The destination bucket for writes.
         * @param precision - Timestamp precision for line items.
         * @param writeOptions - Custom write options.
         * @returns WriteApi instance
         */
        InfluxDB.prototype.getWriteApi = function (org, bucket, precision, writeOptions) {
            if (precision === void 0) { precision = "ns" /* ns */; }
            return new WriteApiImpl(this.transport, org, bucket, precision, writeOptions !== null && writeOptions !== void 0 ? writeOptions : this._options.writeOptions);
        };
        /**
         * Creates QueryApi for the supplied organization .
         *
         * @remarks
         * See also {@link https://github.com/influxdata/influxdb-client-js/blob/master/examples/query.ts | query.ts example},
         * {@link https://github.com/influxdata/influxdb-client-js/blob/master/examples/queryWithParams.ts | queryWithParams.ts example},
         * {@link https://github.com/influxdata/influxdb-client-js/blob/master/examples/rxjs-query.ts | rxjs-query.ts example},
         * and {@link https://github.com/influxdata/influxdb-client-js/blob/master/examples/index.html | browser example},
         *
         * @param org - organization
         * @returns QueryApi instance
         */
        InfluxDB.prototype.getQueryApi = function (org) {
            return new QueryApiImpl(this.transport, org);
        };
        return InfluxDB;
    }());

    exports.AbortError = AbortError;
    exports.DEFAULT_ConnectionOptions = DEFAULT_ConnectionOptions;
    exports.DEFAULT_RetryDelayStrategyOptions = DEFAULT_RetryDelayStrategyOptions;
    exports.DEFAULT_WriteOptions = DEFAULT_WriteOptions;
    exports.FLUX_VALUE = FLUX_VALUE;
    exports.HttpError = HttpError;
    exports.IllegalArgumentError = IllegalArgumentError;
    exports.InfluxDB = InfluxDB;
    exports.Point = Point;
    exports.RequestTimedOutError = RequestTimedOutError;
    exports.canRetryHttpCall = canRetryHttpCall;
    exports.createFluxTableColumn = createFluxTableColumn;
    exports.createFluxTableMetaData = createFluxTableMetaData;
    exports.currentTime = currentTime;
    exports.dateToProtocolTimestamp = dateToProtocolTimestamp;
    exports.escape = escape;
    exports.flux = flux;
    exports.fluxBool = fluxBool;
    exports.fluxDateTime = fluxDateTime;
    exports.fluxDuration = fluxDuration;
    exports.fluxExpression = fluxExpression;
    exports.fluxFloat = fluxFloat;
    exports.fluxInteger = fluxInteger;
    exports.fluxRegExp = fluxRegExp;
    exports.fluxString = fluxString;
    exports.getRetryDelay = getRetryDelay;
    exports.isStatusCodeRetriable = isStatusCodeRetriable;
    exports.sanitizeFloat = sanitizeFloat;
    exports.serializeDateTimeAsDate = serializeDateTimeAsDate;
    exports.serializeDateTimeAsNumber = serializeDateTimeAsNumber;
    exports.serializeDateTimeAsString = serializeDateTimeAsString;
    exports.symbolObservable = symbolObservable;
    exports.toFluxValue = toFluxValue;
    exports.typeSerializers = typeSerializers;
    exports.useProcessHrtime = useProcessHrtime;

    return exports;

}({}));
//# sourceMappingURL=influxdb.js.map
