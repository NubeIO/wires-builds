const config = {
  secretKey: '$SECRET_KEY',
  port: '$PORT',
  dataDir: '$DATA_DIR',
  loopInterval: '$LOOP_INTERVAL',
};

export default config;
